using System;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditorInternal;
using UnityEngine;


[InitializeOnLoad]

public static class StartUpSceneLoader 
{

static StartUpSceneLoader()
{
EditorApplication.playModeStateChanged += LoadstartupScene;
}

    private static void LoadstartupScene(PlayModeStateChange state)
    {
        if(state == PlayModeStateChange.ExitingEditMode)
        {
            EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo();
        }
        if(state == PlayModeStateChange.EnteredPlayMode)
        {
        if(EditorSceneManager.GetActiveScene().buildIndex !=0)
            EditorSceneManager.LoadScene(0);
        }
    }
}