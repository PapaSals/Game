using System.Collections;
using System.Collections.Generic;
using System.Data;
using Fusion;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Experimental.GlobalIllumination;
using UnityEngine.ParticleSystemJobs;



public class TestAcquireGridVisual : MonoBehaviour
{
    [SerializeField] public Transform root;
    [SerializeField] public Transform[] tiles;

    [SerializeField] public GameObject prefabPlaceTile;
    [SerializeField] public Material TileMaterial;
    [SerializeField] public Material PlayerMaterial;
    [SerializeField] public Material LuxorMaterial;
    [SerializeField] public Material GlobalMaterial;
    [SerializeField] public Material ArcadiaMaterial;
    [SerializeField] public Material RegalMaterial;
    [SerializeField] public Material ChainMaterial;
    
    public int [,] TileRef; public int TileRefsPresent; public int [] TileChain;
   
    
    public int p0;public int p10;public int p8;public int p12;public int p4;public int p6;public int p2;public int PT;
    public int p0Id;public int p10Id;public int p8Id;public int p12Id;public int p4Id;public int p6Id;public int p2Id;
  
    public GameObject StartHotelChainPanel;
    public GameObject SharePurchasePanel;
    public static int mergetile; 
    
 
    void Start()
    {
        TileRef= new int[15, 20];   // Grid pattern   0 = empty, 1 = Luxor    20 = no TileRef  19= unplayable tile
        TileChain = new int[182];
    }
    
    private void Awake()
    {
        TileChain = new int[182];

        foreach(var t in tiles)
        {
            GameObject o = Instantiate(prefabPlaceTile, t);

            o.transform.SetLocalPositionAndRotation(Vector3.zero, Quaternion.identity);

            o.transform.localScale = Vector3.one;

            o.transform.SetAsFirstSibling();
            o.gameObject.SetActive(false);

            o.transform.GetChild(0).GetComponent<TextMesh>().text = t.name.Replace("bHex", "");
        }
    }

    public ushort GetTileId(string tileName)
    {
        var obj = root.Find(tileName);
        if (obj == null)
            return 9999;

        return (ushort)obj.GetSiblingIndex();
    }

    [ContextMenu("Add all tiles")]
    private void AddAllTiles()
    {
        List<Transform> tfs = new List<Transform>();
        for (int i = 0; i < root.childCount; i++)
        {
            tfs.Add(root.GetChild(i));
        }

        tiles = tfs.ToArray();
    }

    public void SetTileUnlock(ushort tileId)
    {
        TileChain[tileId]=999;
        var tile = tiles[tileId].GetChild(0);
        tile.gameObject.SetActive(true);
        tile.gameObject.GetComponent<Renderer>().material = TileMaterial;
        tiles[tileId].GetChild(1).gameObject.SetActive(false);
    }

    public void SetTileGhost(ushort tileId)
    {
        var tile = tiles[tileId].GetChild(0);
        tile.gameObject.SetActive(true);
        tile.gameObject.GetComponent<Renderer>().material = PlayerMaterial;

        tiles[tileId].GetChild(1).gameObject.SetActive(false);
    }
    public void SetTileLuxor(ushort tileId)
    {
        var tile = tiles[tileId].GetChild(0);
        tile.gameObject.SetActive(true);
        tile.gameObject.GetComponent<Renderer>().material = LuxorMaterial;

        tiles[tileId].GetChild(1).gameObject.SetActive(false);
    }
    public void SetTileGlobal(ushort tileId)
    {
        var tile = tiles[tileId].GetChild(0);
        tile.gameObject.SetActive(true);
        tile.gameObject.GetComponent<Renderer>().material = GlobalMaterial;

        tiles[tileId].GetChild(1).gameObject.SetActive(false);
    }
    public void SetTileArcadia(ushort tileId)
    {
        var tile = tiles[tileId].GetChild(0);
        tile.gameObject.SetActive(true);
        tile.gameObject.GetComponent<Renderer>().material = ArcadiaMaterial;

        tiles[tileId].GetChild(1).gameObject.SetActive(false);
    }
    public void SetTileRegal(ushort tileId)
    {
        var tile = tiles[tileId].GetChild(0);
        tile.gameObject.SetActive(true);
        tile.gameObject.GetComponent<Renderer>().material = RegalMaterial;

        tiles[tileId].GetChild(1).gameObject.SetActive(false);
    }
    
    public void SetTileCheck(ushort tileId)
    {
        p12 = 0; p2 = 0;  p4 = 0; p6 = 0; p8 = 0; p10 = 0; PT = 0;
        p12Id = 0; p2Id = 0; p4Id = 0; p6Id = 0; p8Id = 0; p10Id = 0;

        Debug.Log("Tile placed = "+ tileId);
    
        if(tileId == 0) //Column A
        {
            p6  = TileChain[tileId + 1];        p6Id=tileId+1;
            p4  = TileChain[tileId + 13];       p4Id=tileId+13;
        }  
        else if(tileId >= 1 && tileId <= 11)  //Column A
        {
            p12 = TileChain[tileId - 1];        p12Id=tileId-1;
            p6  = TileChain[tileId + 1];        p6Id=tileId+1;
            p2  = TileChain[tileId + 12];       p2Id=tileId+12;
            p4  = TileChain[tileId + 13];       p4Id=tileId+13;
        }  
        else if(tileId == 12) //Column A
        {
            p12 = TileChain[tileId - 1];        p12Id=tileId-1;
            p6  = TileChain[tileId + 1];        p6Id=tileId+1;
            p4  = TileChain[tileId + 13];       p4Id=tileId+13;
        }  
        else if(tileId == 13 || tileId == 39 || tileId == 65 || tileId == 91 || tileId == 117 || tileId == 143) //Top Row
        {
            p10 = TileChain[tileId - 13];       p10Id=tileId-13;
            p8  = TileChain[tileId - 12];       p8Id=tileId-12;
            p6  = TileChain[tileId + 1];        p6Id=tileId+1;
            p2  = TileChain[tileId + 13];       p2Id=tileId+13;
            p4  = TileChain[tileId + 14];       p4Id=tileId+14;
        }  
        else if(tileId == 26 || tileId == 52|| tileId == 78 || tileId == 104 || tileId == 130) //Top Row 
        {
            p8 = TileChain[tileId - 13];        p8Id=tileId-13;
            p6  = TileChain[tileId + 1];        p6Id=tileId+1;
            p4  = TileChain[tileId + 13];       p4Id=tileId+13;
        }  
        else if(tileId == 25 || tileId == 51 || tileId == 77 || tileId == 103  || tileId == 129 || tileId == 155) //Bottom Row 
        {
            p10 = TileChain[tileId - 13];       p10Id=tileId-13;
            p12  = TileChain[tileId - 1];       p12Id=tileId-1;
            p2  = TileChain[tileId + 13];       p2Id=tileId+13;     
        }  
        else if(tileId == 38 || tileId == 64 || tileId == 90 || tileId == 126  || tileId == 142 || tileId == 168) //Bottom Row 
        {
            p8 = TileChain[tileId - 13];        p8Id=tileId-13;
            p10  = TileChain[tileId - 14];      p10Id=tileId-14;
            p12  = TileChain[tileId - 1];       p12Id=tileId-1;
            p2  = TileChain[tileId + 12];       p2Id=tileId+12;
            p4  = TileChain[tileId + 13];       p4Id=tileId+13;
        }  
        else if(tileId == 181) //N Column
        {
            p10  = TileChain[tileId - 1];       p10Id=tileId-1;
            p12  = TileChain[tileId - 13];      p12Id=tileId-13;
        }  
        else if(tileId == 169) //N Column
        {
            p6 = TileChain[tileId +1 ];         p6Id=tileId+1;
            p8  = TileChain[tileId - 12];       p8Id=tileId-12;
            p10  = TileChain[tileId -13];       p10Id=tileId-13;
        }  
        else if(tileId >= 170 && tileId <= 180) //N Column
        {
            p6= TileChain[tileId + 1];          p6Id=tileId+1;
            p8  = TileChain[tileId - 12];       p8Id=tileId-12;
            p10  = TileChain[tileId - 13];      p10Id=tileId-13;
            p12  = TileChain[tileId - 1];       p12Id=tileId-1;
        }  
        if(tileId >= 14 && tileId <= 24 || tileId >= 40 && tileId <= 50|| tileId >= 66 && tileId <= 76|| tileId >= 92 && tileId <= 102|| tileId >= 118 && tileId <= 128 || tileId >= 144 && tileId <= 154) //body
        {
            p10 = TileChain[tileId - 13];   p10Id=tileId-13;
            p8  = TileChain[tileId - 12];   p8Id=tileId-12;
            p12 = TileChain[tileId - 1];    p12Id=tileId-1;
            p6  = TileChain[tileId + 1];    p6Id=tileId+1;
            p2  = TileChain[tileId + 13];   p2Id=tileId+13;
            p4  = TileChain[tileId + 14];   p4Id=tileId+14;
        }
         if(tileId >= 27 && tileId <= 37 || tileId >= 53 && tileId <= 63|| tileId >= 79 && tileId <= 89|| tileId >= 105 && tileId <= 115|| tileId >= 131 && tileId <= 141 || tileId >= 157 && tileId <= 167) // body
        {
            p10 = TileChain[tileId - 14];   p10Id=tileId-14;
            p8  = TileChain[tileId - 13];   p8Id=tileId-13;
            p12 = TileChain[tileId - 1];    p12Id=tileId-1;
            p6  = TileChain[tileId + 1];    p6Id=tileId+1;
            p2  = TileChain[tileId + 12];   p2Id=tileId+12;
            p4  = TileChain[tileId + 13];   p4Id=tileId+13;
        }
        
        p0 = 999; 
        p0Id=tileId;   
        PT = p12 + p2 + p4 + p6 + p8 + p10;
     
             
        //Debug.Log("L226                                               "+p12+"                                  "+p12Id);
        //Debug.Log("L227                                      "+p10+"            "+p2+"                     "+p10Id+"           "+p2Id);
        //Debug.Log("L228                                           "+p0+"                                "+p0Id);
        //Debug.Log("L229                                      "+p8 +"            "+p4+"                     "+p8Id+"            "+p4Id);
        //Debug.Log("L230                                               "+p6+"                                 "+p6Id);
                
            
        if(PT == 0 )   //  Single Tile
        {
            Debug.Log("Solitary Tile Placed");
            
            HotelData.HotelNum = 0;
            TileChain[tileId] = 999;
            StartHotelChainPanel.SetActive(false);
            FindObjectOfType<StartingHotel>().AddtoChain();
           
           
        } 
        else if(PT == 999 || PT == 1998 || PT == 2997 || PT == 3996 || PT == 4995)   //  Start a Chain
        {
            Debug.Log("Start a Chain");
            if(HotelData.HotelCount < HotelData.MaxHotel){StartHotelChainPanel.SetActive(true);}
        } 
        else if(p12 == 10 || p2 == 10 || p4 == 10 || p6 == 10 || p8 == 10 || p10 == 10)   //  Add to Luxor Chain
        {
            Debug.Log("Adding to Luxor");
            HotelData.HotelNum = 1;
            StartHotelChainPanel.SetActive(false);
                      
            FindObjectOfType<StartingHotel>().AddtoChain();
        } 
        else if(p12 == 50 || p2 == 50 || p4 == 50 || p6 == 50 || p8 == 50 || p10 == 50)   //  Add to Global Chain
        {
            Debug.Log("Adding to Global");
            HotelData.HotelNum = 5;
            StartHotelChainPanel.SetActive(false);
                      
            FindObjectOfType<StartingHotel>().AddtoChain();
        } 
            else if(p12 == 70 || p2 == 70 || p4 == 70 || p6 == 70 || p8 == 70 || p10 == 70)   //  Add to Arcadia Chain
        {
            Debug.Log("Adding to Arcadia");
            HotelData.HotelNum = 7;
            StartHotelChainPanel.SetActive(false);
                      
            FindObjectOfType<StartingHotel>().AddtoChain();
        } 
        else if(p12 == 110 || p2 == 110 || p4 == 110 || p6 == 110 || p8 == 110 || p10 == 110)   //  Add to Regal Chain
        {
            Debug.Log("Adding to Regal");
            HotelData.HotelNum = 11;
            StartHotelChainPanel.SetActive(false);
                      
            FindObjectOfType<StartingHotel>().AddtoChain();
        } 
        else if(PT < 999)   ///Add to a Chain
        {
            Debug.Log("PT < 999");
            StartHotelChainPanel.SetActive(false);
                      
           
            
        } 
        //SharePurchasePanel.SetActive(true);
    }  
    
           
     
}


