using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UIElements;


public class TestAcquireClickTile : MonoBehaviour
{
    public System.Action<string> OnClickTile;

    private void Update()
    {
        


        if(Input.GetMouseButtonUp(0))
        {
            var ray = Camera.main.ScreenPointToRay(Input.mousePosition);

            if(Physics.Raycast(ray, out var hit, 100f))
            {
                Debug.Log("ClickTile L26   placing tile");
                OnClickTile?.Invoke(hit.collider.name);        // GameHandler L41 to place a tile
                

            }
        }
       
    }



    public void OnMouseOver()  // not working
    {
       Debug.Log("Over"); 
       
                 
    }
   

  
    
          
    
}
