using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SampleUIRoom : MonoBehaviour
{
    [SerializeField] private SampleUIRoom_Player playerPrefab;

    [SerializeField] private Transform root;
    [SerializeField] private Toggle toggleReady;

    private Dictionary<string, SampleUIRoom_Player> playerMapping = new Dictionary<string, SampleUIRoom_Player>();

    private NetworkRoom room;
    private Dictionary<string, bool> cachingPlayers = new Dictionary<string, bool>();

    [SerializeField] private Button buttonStartGame;

    private void Start()
    {
        room = FindObjectOfType<NetworkRoom>();
    }

    private float updateCooldown = 0.5f;
    private float nextUpdate;
    private void LateUpdate()
    {
        if (nextUpdate > Time.time)
            return;

        UpdatePlayers();
        UpdateButtonStartGame();

    }

    private void UpdatePlayers()
    {
        nextUpdate = Time.time + updateCooldown;

        cachingPlayers.Clear();

        room.GetPlayers(cachingPlayers);

        List<string> removeList = new List<string>();
        removeList.AddRange(playerMapping.Keys);

        foreach (var kv in cachingPlayers)
        {
            string name = kv.Key;
            if (!playerMapping.TryGetValue(name, out var playerUI))
            {
                playerMapping[name] = playerUI = Instantiate(playerPrefab, root);
                playerUI.SetPlayerName(name);
                playerUI.gameObject.SetActive(true);
            }
            playerUI.SetPlayerReady(kv.Value);
            removeList.Remove(name);
        }

        if (removeList.Count > 0)
        {
            foreach (var key in removeList)
            {
                playerMapping.Remove(key, out var playerUI);
                Destroy(playerUI.gameObject);
            }
        }
    }

    private void UpdateButtonStartGame()
    {
        buttonStartGame.gameObject.SetActive(room.IsRoomOwner() && room.IsAllPlayerReady());
    }

    public void StartGame()
    {
        room.StartGame();
    }

    public void SetReady(bool isReady)
    {
        room.SetReady(isReady);
    }
}
