using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SampleUIRoot : MonoBehaviour
{
    [SerializeField] private Canvas canvasRoom;
    [SerializeField] private Canvas canvasGame;
    

    private NetworkRoom room;
    private bool isGameReadyFlag;

    private void Start()
    {
        canvasGame.enabled = false;
        canvasRoom.enabled = true;
        

        room = FindObjectOfType<NetworkRoom>();
    }

    public void ActiveGameCanvas()
    {
        canvasGame.enabled = true;
        canvasRoom.enabled = false;
    }

    private void Update()
    {
        if(isGameReadyFlag ^room.IsStarted)
        {
            isGameReadyFlag = room.IsStarted;

            if(isGameReadyFlag)
            {
                ActiveGameCanvas();
            }
        }
    }
}
