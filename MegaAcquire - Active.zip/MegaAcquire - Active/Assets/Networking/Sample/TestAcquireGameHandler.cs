using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;


public class TestAcquireGameHandler : MonoBehaviour, IBaseAcquireHandler
{
    private NetworkAcquireSample acquireGame;    // makes method available

    [SerializeField] private int totalTile;
    [SerializeField] private int tileOpenAtStartGame;
    [SerializeField] private int tileOpenPerPlayer;
    [SerializeField] private int startingCashAmount;
    [SerializeField] private List<ushort> shuffleBags;
    [SerializeField] private List<ushort> openedTiles;

    [SerializeField] private byte myPlayerId;

    private TestAcquireGridVisual gridVisual;   // makes gridVisual method available
    private StartingHotel startHotel; 
    private TestAcquireGridVisual chainTile; 

    [System.Serializable]
    private class PlayerTrack
    {        
        public int cashAmount;
        public List<ushort> tiles;
    }

    [SerializeField] private PlayerTrack[] players;



    void Awake()
    {
        acquireGame = GetComponent<NetworkAcquireSample>();
        acquireGame.Handler = this;

        gridVisual = FindObjectOfType<TestAcquireGridVisual>();
        startHotel =  FindObjectOfType<StartingHotel>();
        //chainTile =  FindObjectOfType<TestAcquireGridVisual>();

        TestAcquireClickTile clickTile = FindObjectOfType<TestAcquireClickTile>();
        clickTile.OnClickTile = OnClickTile;
    }

    private void OnClickTile(string id)
    {
        Debug.Log("myPlayerId = "+ myPlayerId);
        ushort tileId = gridVisual.GetTileId(id); 
        //Debug.Log("tileID = " + tileId);
        //Debug.Log("!acquireGame.IsMyTurn() = " + !acquireGame.IsMyTurn());

        if (!acquireGame.IsMyTurn())
            return;

        var player = players[myPlayerId];
        //Debug.Log("Player = " + player);
        //Debug.Log("player.tiles.Contains(tileId) = " + player.tiles.Contains(tileId));

        if (!player.tiles.Contains(tileId))
            return;

        acquireGame.RpcOpenTile(tileId);

        //end turn
        //
        acquireGame.RpcEndMyTurn();
    }

    public void HandleLogicStartGame()
    {
        //random bags
        for (int i = 0; i < totalTile; i++)
        {
            shuffleBags.Add((ushort)i);
        }

        int n = shuffleBags.Count;
        System.Random rand = new System.Random(acquireGame.RandomSeed);
        while( n > 1)
        {
            n--;
            int k = rand.Next(n + 1);
            var temp = shuffleBags[k];
            shuffleBags[k] = shuffleBags[n];
            shuffleBags[n] = temp;
        }

        for (int i = 0; i < tileOpenAtStartGame; i++)
        {
            ushort v = shuffleBags[0];
            shuffleBags.RemoveAt(0);
            openedTiles.Add(v);
            Debug.Log(v);
            gridVisual.TileChain[v] = 999; // tile wih no chain affiliation
          
              // Seting values on dealt cards to the public
        
            
            }

        int playerCount = acquireGame.PlayerCount;

        Debug.Log("Initialize with playercount: " + playerCount);
        players = new PlayerTrack[playerCount];
        for (int i = 0; i < playerCount; i++)
        {
            var p = new PlayerTrack();
            p.cashAmount = startingCashAmount;
            var list = new List<ushort>();
            for (int j = 0; j < tileOpenPerPlayer; j++)
            {
                ushort v = shuffleBags[0];
                shuffleBags.RemoveAt(0);
                list.Add(v);
            }
            p.tiles = list;
            players[i] = p;
        }

        myPlayerId = acquireGame.GetMyPlayerId();
    }

    public void HandleVisualStartGame()
    {
        Debug.Log("Start game!");

        PlayerTrack curTrack = players[myPlayerId];

        Debug.Log("My Player Id = "+ myPlayerId);

        foreach(var t in curTrack.tiles)
        {
            gridVisual.SetTileGhost(t);
        }

        foreach(var t in openedTiles)
        {
            gridVisual.SetTileUnlock(t);
        }
    }

    public bool HandleLogicMerge(byte playerId, ushort tileId, byte mergeSelection)
    {
        return true;
    }

    public bool HandleLogicPlace(byte playerId, ushort tileId)
    {
        if(openedTiles.Contains(tileId))
        {
            
            return false;
        }

        openedTiles.Add(tileId);   // e can do some check later, for example, when we need to check if our willing-to-open tile is near any already-opened tile

        gridVisual.SetTileUnlock(tileId);  // shows the tile to all players
        Debug.Log("------------------  HandleLogicPlace  ------------------");
        Debug.Log("Player is "+playerId);
        
        gridVisual.SetTileCheck(tileId);
        

        return true;

      

    }

    public bool HandleLogicCreateChain(byte playerId, ushort tileId, byte chainId)
    {
        gridVisual.SetTileCheck(tileId);
        FindObjectOfType<StartingHotel>().StartHotelChainPanel.SetActive(true);
        return true;
    }

    public void HandleVisualNextMergeTurn(bool isMergeTurnEnabled, bool isMyMergeTurn)
    {
        if (isMergeTurnEnabled)
        {
            Debug.Log($"Merge turn: {acquireGame.MergeTurn}: isMine = {isMyMergeTurn}");
        }
        else
        {
            Debug.Log("Merge turn ended!");
        }
    }

    public void HandleVisualNextTurn(bool isMyTurn)
    {
        Debug.Log($"Turn #{acquireGame.CurrentTurn}: isMine={isMyTurn}");
    }    

    public int[] SortPlayerToBeginMerge(ushort tileId, byte mergeSelection)
    {
        int[] ids = new int[acquireGame.PlayerCount];
        for (int i = 0; i < acquireGame.PlayerCount; i++)
        {
            ids[i] = i;
        }
        return ids;
    }

    public bool HandleLogicPurchaseShare(byte playerId, byte[] hotelIds, byte[] amounts)
    {
        return true;
    }

    public bool HandleLogicSellShare(byte playerId, byte hotelId, byte amount)
    {
        return true;
    }

    public bool HandleLogicExchangeShare(byte playerId, byte hotelId, byte amount)
    {
        return true;
    }

    
}
