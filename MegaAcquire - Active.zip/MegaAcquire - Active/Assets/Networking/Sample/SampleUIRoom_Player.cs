using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SampleUIRoom_Player : MonoBehaviour
{
    [SerializeField] private Text text;
    [SerializeField] private GameObject toggleObj;

    public void SetPlayerName(string name)
    {
        text.text = name;
    }

    public void SetPlayerReady(bool ready)
    {
        toggleObj.SetActive(ready);
    }
}
