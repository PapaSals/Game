using System;
using System.Collections;
using System.Collections.Generic;
using Unity.Burst;
using UnityEngine;
using UnityEngine.UI;

public class MajorityBonus : MonoBehaviour
{
    public static int[] MergerPlayerShares;
    public GameObject MergerDistributionPanel;

   public static int[,] Rank;  public static int[] RankNum; public static string[] RankPlayer;public static int AfterMathCount;
    //private int maxplayers = 6;

    public static int P1MajorityBonus;public static int P2MajorityBonus;public static int P3MajorityBonus;public static int P4MajorityBonus;public static int P5MajorityBonus;public static int P6MajorityBonus;
    
    public void Start()
    {
    Rank = new int [7,15];
    RankNum = new int [7];
    RankPlayer = new string [7];

    }
 
     public void CalculateShares()
    {
        
        int c = TwoMerger.MergerChainNumber;
        Rank[1,c]=ShareManager.PlayerShares[1,c];RankPlayer[1]=ShareManager.PlayerName[1];
        Rank[2,c]=ShareManager.PlayerShares[2,c];RankPlayer[2]=ShareManager.PlayerName[2];
        Rank[3,c]=ShareManager.PlayerShares[3,c];RankPlayer[3]=ShareManager.PlayerName[3];
        Rank[4,c]=ShareManager.PlayerShares[4,c];RankPlayer[4]=ShareManager.PlayerName[4];
        Rank[5,c]=ShareManager.PlayerShares[5,c];RankPlayer[5]=ShareManager.PlayerName[5];
        Rank[6,c]=ShareManager.PlayerShares[6,c];RankPlayer[6]=ShareManager.PlayerName[6];
        Debug.Log(RankPlayer[1]=ShareManager.PlayerName[1] + "   " +Rank[1,c]);
        Debug.Log(RankPlayer[2]=ShareManager.PlayerName[2] + "   " +Rank[2,c]);
        Debug.Log(RankPlayer[3]=ShareManager.PlayerName[3] + "   " +Rank[3,c]);
        Debug.Log(RankPlayer[4]=ShareManager.PlayerName[4] + "   " +Rank[4,c]);
        Debug.Log(RankPlayer[5]=ShareManager.PlayerName[5] + "   " +Rank[5,c]);
        Debug.Log(RankPlayer[6]=ShareManager.PlayerName[6] + "   " +Rank[6,c]);

        int i; AfterMathCount=0;
        for (i=1;i<7;i++)
        {
            if(Rank[i,c] > 0)
            {
            AfterMathCount ++;
            }
        }

;               
            if (ShareManager.PlayerShares[1,c] >= ShareManager.PlayerShares[2,c])   
            { 
                Rank[1,c] = ShareManager.PlayerShares[1,c];RankPlayer[1]=ShareManager.PlayerName[1];RankNum[1]=1;
                Rank[2,c] = ShareManager.PlayerShares[2,c];RankPlayer[2]=ShareManager.PlayerName[2];RankNum[2]=2;
                Debug.Log("Player 1 now 1st " + Rank[1,c] + "  " + Rank[2,c]);
            }
            else
            {
                Rank[1,c] = ShareManager.PlayerShares[2,c];RankPlayer[1]=ShareManager.PlayerName[2];RankNum[1]=2;
                Rank[2,c] = ShareManager.PlayerShares[1,c];RankPlayer[2]=ShareManager.PlayerName[1];RankNum[2]=1;
                Debug.Log("Player 2 now 1st " + Rank[1,c] + "  " + Rank[2,c]);
            }
                          
            Debug.Log("Player 3 is :  " + ShareManager.PlayerShares[3,c]+ " with " +Rank[3,c] +" hotels"); 
            
            Debug.Log("Player 1 is has " + Rank[1,c] +" shares");
            Debug.Log("Player 1 is has " + Rank[1,c] + "  " + ShareManager.PlayerShares[RankNum[1],c]);

        if (ShareManager.PlayerShares[3,c] == 0 ) 
            {
                // Player 3 shares are 0
            } 
        else
        {
            if (ShareManager.PlayerShares[3,c] >= ShareManager.PlayerShares[RankNum[1],c])  
            { 
                Debug.Log(" ---- first look at Player 3 Shares= " + ShareManager.PlayerShares[3,c] + " Rank 1 Shares =  " +ShareManager.PlayerShares[Rank[1,c],c]);
                Debug.Log(" ---- first look at Player 3  = " + Rank[1,c] + "  " + Rank[2,c]+ " " + Rank[3,c]);  
                Debug.Log("---- first look at Player 3  = " + RankNum[1] + " " + RankNum[2]+"   " + RankNum[3]);

                Rank[3,c] = Rank[2,c];RankPlayer[3]=RankPlayer[2];RankNum[3]=RankNum[2];
                Rank[2,c] = Rank[1,c];RankPlayer[2]=RankPlayer[1];RankNum[2]=RankNum[1];
                Rank[1,c] = ShareManager.PlayerShares[3,c];RankPlayer[1]=ShareManager.PlayerName[3];RankNum[1]=3;
                Debug.Log("Player 3 now 1st   " + Rank[1,c] + "  " + Rank[2,c] + "  " + Rank[3,c] + "  " + Rank[4,c]+ "  "+Rank[5,c]+ "  " + Rank[6,c]);
            }
            else if (ShareManager.PlayerShares[3,c] >= ShareManager.PlayerShares[RankNum[2],c])  
            {
                
                Rank[3,c] = Rank[2,c];RankPlayer[3]=RankPlayer[2];RankNum[3]=RankNum[2];
                Rank[2,c] = ShareManager.PlayerShares[3,c];RankPlayer[2]=ShareManager.PlayerName[3];RankNum[2]=3;
                Debug.Log("Player 3 moves to 2nd " + Rank[1,c] + "  " + Rank[2,c] + "  " + Rank[3,c] + "  " + Rank[4,c]+ "  "+Rank[5,c]+ "  " + Rank[6,c]);
            }
            else 
            { 
                Rank[3,c] = ShareManager.PlayerShares[3,c];RankPlayer[3]=ShareManager.PlayerName[3];RankNum[3]=3;
                Debug.Log("                       "+ Rank[1,c] + "  " + Rank[2,c] + "  " + Rank[3,c] + "  " + Rank[4,c]+ "  "+Rank[5,c]+ "  " + Rank[6,c]);
                Debug.Log("Player 3 remains at 3rd"+ Rank[1,c] + "  " + Rank[2,c] + "  " + Rank[3,c] + "  " + Rank[4,c]+ "  "+Rank[5,c]+ "  " + Rank[6,c]);
            }

        } 
        Debug.Log("---- first look at Player 4  = " + Rank[1,c] + "   " + Rank[2,c]+ "   " + Rank[3,c] +"    " + Rank[4,c]+"    " + Rank[5,c] + "   " + Rank[6,c]);
        Debug.Log("---- Player 4 Number         = " + RankNum[1] + "   " + RankNum[2]+"   " + RankNum[3] +"    " + RankNum[4]+"    " + RankNum[5]+"    " + RankNum[6]);

        if (ShareManager.PlayerShares[4,c] == 0 ) 
            {
                // Player 4 shares are 0
            } 
        else
        {
            if (ShareManager.PlayerShares[4,c] >= ShareManager.PlayerShares[RankNum[1],c])  
            {
                Rank[4,c] = Rank[3,c];RankPlayer[4]=RankPlayer[3];RankNum[4]=RankNum[3];
                Rank[3,c] = Rank[2,c];RankPlayer[3]=RankPlayer[2];RankNum[3]=RankNum[2];
                Rank[2,c] = Rank[1,c];RankPlayer[2]=RankPlayer[1];RankNum[2]=RankNum[1];
                Rank[1,c] = ShareManager.PlayerShares[4,c];RankPlayer[1]=ShareManager.PlayerName[4];RankNum[1]=4;
                Debug.Log("Player 4 moves to 1st "+ Rank[1,c] + "  " + Rank[2,c] + "  " + Rank[3,c] + "  " + Rank[4,c]+ "  "+Rank[5,c]+ "  " + Rank[6,c]);
            }
            else if (ShareManager.PlayerShares[4,c] >= ShareManager.PlayerShares[RankNum[2],c])  
            {
                Rank[4,c] = Rank[3,c];RankPlayer[4]=RankPlayer[3];RankNum[4]=RankNum[3];
                Rank[3,c] = Rank[2,c];RankPlayer[3]=RankPlayer[2];RankNum[3]=RankNum[2];
                Rank[2,c] = ShareManager.PlayerShares[4,c];RankPlayer[2]=ShareManager.PlayerName[4];RankNum[2]=4;
                Debug.Log("Player 4 moves to 2nd  "+ Rank[1,c] + "  " + Rank[2,c] + "  " + Rank[3,c] + "  " + Rank[4,c]+ "  "+Rank[5,c]+ "  " + Rank[6,c]);
            }
            else if (ShareManager.PlayerShares[4,c] >= ShareManager.PlayerShares[RankNum[3],c])  
             {
                Rank[4,c] = Rank[3,c];RankPlayer[4]=RankPlayer[3];RankNum[4]=RankNum[3];
                Rank[3,c] = ShareManager.PlayerShares[4,c];RankPlayer[3]=ShareManager.PlayerName[4];RankNum[3]=4;
                Debug.Log("Player 4 moves to 3rd  "+ Rank[1,c] + "  " + Rank[2,c] + "  " + Rank[3,c] + "  " + Rank[4,c]+ "  "+Rank[5,c]+ "  " + Rank[6,c]);
            }
            else 
            {
                Rank[4,c] = ShareManager.PlayerShares[4,c];RankPlayer[4]=ShareManager.PlayerName[4];RankNum[4]=4;
                Debug.Log(Rank[1,c] + " " + Rank[2,c] + "  " + Rank[3,c] + "  " + Rank[4,c]);
                Debug.Log("Player 4 remains at 4th "+ Rank[1,c] + "  " + Rank[2,c] + "  " + Rank[3,c] + "  " + Rank[4,c]+ "  "+Rank[5,c]+ "  " + Rank[6,c]);
            }
        }
        Debug.Log("---- first look at Player 5  = " + Rank[1,c] + "   " + Rank[2,c]+ "   " + Rank[3,c] +"    " + Rank[4,c]+"    " + Rank[5,c] + "   " + Rank[6,c]);
        Debug.Log("---- Player 5 Number         = " + RankNum[1] + "   " + RankNum[2]+"   " + RankNum[3] +"    " + RankNum[4]+"    " + RankNum[5]+"    " + RankNum[6]);
        
        if (ShareManager.PlayerShares[5,c] == 0 ) 
            {
                // Player 5 shares are 0
            } 
        else
        {
            if (ShareManager.PlayerShares[5,c] >= ShareManager.PlayerShares[RankNum[1],c])  
            {
                Rank[5,c] = Rank[4,c];RankPlayer[5]=RankPlayer[4];RankNum[5]=RankNum[4];
                Rank[4,c] = Rank[3,c];RankPlayer[4]=RankPlayer[3];RankNum[4]=RankNum[3];
                Rank[3,c] = Rank[2,c];RankPlayer[3]=RankPlayer[2];RankNum[3]=RankNum[2];
                Rank[2,c] = Rank[1,c];RankPlayer[2]=RankPlayer[1];RankNum[2]=RankNum[1];
                Rank[1,c] = ShareManager.PlayerShares[5,c];RankPlayer[1]=ShareManager.PlayerName[5];RankNum[1]=5;
                Debug.Log("Player 5 moves to 1st "+ Rank[1,c] + "  " + Rank[2,c] + "  " + Rank[3,c] + "  " + Rank[4,c]+ "  "+Rank[5,c]+ "  " + Rank[6,c]);
            }
            else if (ShareManager.PlayerShares[5,c] >= ShareManager.PlayerShares[RankNum[2],c])  
            {
                Rank[5,c] = Rank[4,c];RankPlayer[5]=RankPlayer[4];RankNum[5]=RankNum[4];
                Rank[4,c] = Rank[3,c];RankPlayer[4]=RankPlayer[3];RankNum[4]=RankNum[3];
                Rank[3,c] = Rank[2,c];RankPlayer[3]=RankPlayer[2];RankNum[3]=RankNum[2];
                Rank[2,c] = ShareManager.PlayerShares[5,c];RankPlayer[2]=ShareManager.PlayerName[5];RankNum[2]=5;
                Debug.Log("Player 5 moves to 2nd  "+ Rank[1,c] + "  " + Rank[2,c] + "  " + Rank[3,c] + "  " + Rank[4,c]+ "  "+Rank[5,c]+ "  " + Rank[6,c]);
            }
            else if (ShareManager.PlayerShares[5,c] >= ShareManager.PlayerShares[RankNum[3],c])  
            {
                Rank[5,c] = Rank[4,c];RankPlayer[5]=RankPlayer[4];RankNum[5]=RankNum[4];
                Rank[4,c] = Rank[3,c];RankPlayer[4]=RankPlayer[3];RankNum[4]=RankNum[3];
                Rank[3,c] = ShareManager.PlayerShares[5,c];RankPlayer[3]=ShareManager.PlayerName[5];RankNum[3]=5;
                Debug.Log("Player 5 moves to 3rd  "+ Rank[1,c] + "  " + Rank[2,c] + "  " + Rank[3,c] + "  " + Rank[4,c]+ "  "+Rank[5,c]+ "  " + Rank[6,c]);
            }
            else if (ShareManager.PlayerShares[5,c] >= ShareManager.PlayerShares[RankNum[4],c])  
             {
                Rank[5,c] = Rank[4,c];RankPlayer[5]=RankPlayer[4];RankNum[5]=RankNum[4];
                Rank[4,c] = ShareManager.PlayerShares[5,c];RankPlayer[4]=ShareManager.PlayerName[5];RankNum[4]=5;
                Debug.Log("Player 5 moves to 4th  "+ Rank[1,c] + "  " + Rank[2,c] + "  " + Rank[3,c] + "  " + Rank[4,c]+ "  "+Rank[5,c]+ "  " + Rank[6,c]);
            }
            else 
            {
                Rank[5,c] = ShareManager.PlayerShares[5,c];RankPlayer[5]=ShareManager.PlayerName[5];RankNum[5]=5;
                Debug.Log(Rank[1,c] + " " + Rank[2,c] + "  " + Rank[3,c] + "  " + Rank[4,c]);
                Debug.Log("Player 5 remains at 5th "+ Rank[1,c] + "  " + Rank[2,c] + "  " + Rank[3,c] + "  " + Rank[4,c]+ "  "+Rank[5,c]+ "  " + Rank[6,c]);
            }
        }
        Debug.Log("---- first look at Player 6  = " + Rank[1,c] + "   " + Rank[2,c]+ "   " + Rank[3,c] +"    " + Rank[4,c]+"    " + Rank[5,c] + "   " + Rank[6,c]);
        Debug.Log("---- Player 6 Number         = " + RankNum[1] + "   " + RankNum[2]+"   " + RankNum[3] +"    " + RankNum[4]+"    " + RankNum[5]+"    " + RankNum[6]);
        if (ShareManager.PlayerShares[6,c] == 0 ) 
            {
                // Player 6 shares are 0
            } 
        else 
        {
            if (ShareManager.PlayerShares[6,c] >= ShareManager.PlayerShares[RankNum[1],c])  
            {
                Rank[6,c] = Rank[5,c];RankPlayer[6]=RankPlayer[5];RankNum[6]=RankNum[5];
                Rank[5,c] = Rank[4,c];RankPlayer[5]=RankPlayer[4];RankNum[5]=RankNum[4];
                Rank[4,c] = Rank[3,c];RankPlayer[4]=RankPlayer[3];RankNum[4]=RankNum[3];
                Rank[3,c] = Rank[2,c];RankPlayer[3]=RankPlayer[2];RankNum[3]=RankNum[2];
                Rank[2,c] = Rank[1,c];RankPlayer[2]=RankPlayer[1];RankNum[2]=RankNum[1];
                Rank[1,c] = ShareManager.PlayerShares[6,c];RankPlayer[1]=ShareManager.PlayerName[6];RankNum[1]=6;
                Debug.Log("Player 6 moves to 1st "+ Rank[1,c] + "  " + Rank[2,c] + "  " + Rank[3,c] + "  " + Rank[4,c]+ "  "+Rank[5,c]+ "  " + Rank[6,c]);
            }
            else if (ShareManager.PlayerShares[6,c] >= ShareManager.PlayerShares[RankNum[2],c])  
            {
                Rank[6,c] = Rank[5,c];RankPlayer[6]=RankPlayer[5];RankNum[6]=RankNum[5];
                Rank[5,c] = Rank[4,c];RankPlayer[5]=RankPlayer[4];RankNum[5]=RankNum[4];
                Rank[4,c] = Rank[3,c];RankPlayer[4]=RankPlayer[3];RankNum[4]=RankNum[3];
                Rank[3,c] = Rank[2,c];RankPlayer[3]=RankPlayer[2];RankNum[3]=RankNum[2];
                Rank[2,c] = ShareManager.PlayerShares[6,c];RankPlayer[2]=ShareManager.PlayerName[6];RankNum[2]=6;
                Debug.Log("Player 6 moves to 2nd  "+ Rank[1,c] + "  " + Rank[2,c] + "  " + Rank[3,c] + "  " + Rank[4,c]+ "  "+Rank[5,c]+ "  " + Rank[6,c]);
            }
            else if (ShareManager.PlayerShares[6,c] >= ShareManager.PlayerShares[RankNum[3],c])  
            {
                Rank[6,c] = Rank[5,c];RankPlayer[6]=RankPlayer[5];RankNum[6]=RankNum[5];
                Rank[5,c] = Rank[4,c];RankPlayer[5]=RankPlayer[4];RankNum[5]=RankNum[4];
                Rank[4,c] = Rank[3,c];RankPlayer[4]=RankPlayer[3];RankNum[4]=RankNum[3];
                Rank[3,c] = ShareManager.PlayerShares[6,c];RankPlayer[3]=ShareManager.PlayerName[6];RankNum[3]=6;
                Debug.Log("Player 6 moves to 3rd  "+ Rank[1,c] + "  " + Rank[2,c] + "  " + Rank[3,c] + "  " + Rank[4,c]+ "  "+Rank[5,c]+ "  " + Rank[6,c]);
            }
            else if (ShareManager.PlayerShares[6,c] >= ShareManager.PlayerShares[RankNum[4],c])  
             {
                Rank[6,c] = Rank[5,c];RankPlayer[6]=RankPlayer[5];RankNum[6]=RankNum[5];
                Rank[5,c] = Rank[4,c];RankPlayer[5]=RankPlayer[4];RankNum[5]=RankNum[4];
                Rank[4,c] = ShareManager.PlayerShares[6,c];RankPlayer[4]=ShareManager.PlayerName[6];RankNum[4]=6;
                Debug.Log("Player 6 moves to 4th  "+ Rank[1,c] + "  " + Rank[2,c] + "  " + Rank[3,c] + "  " + Rank[4,c]+ "  "+Rank[5,c]+ "  " + Rank[6,c]);
            }
            else if (ShareManager.PlayerShares[6,c] >= ShareManager.PlayerShares[RankNum[5],c])  
            {
                Rank[6,c] = Rank[5,c];RankPlayer[6]=RankPlayer[5];RankNum[6]=RankNum[5];
                Rank[5,c] = ShareManager.PlayerShares[6,c];RankPlayer[5]=ShareManager.PlayerName[6];RankNum[4]=6;
                Debug.Log("Player 6 moves to 5th  "+ Rank[1,c] + "  " + Rank[2,c] + "  " + Rank[3,c] + "  " + Rank[4,c]+ "  "+Rank[5,c]+ "  " + Rank[6,c]);
            }
            else 
            {
                Rank[6,c] = ShareManager.PlayerShares[6,c];RankPlayer[6]=ShareManager.PlayerName[6];RankNum[5]=6;
                Debug.Log(Rank[1,c] + " " + Rank[2,c] + "  " + Rank[3,c] + "  " + Rank[4,c]);
                Debug.Log("Player 6 remains at 6th "+ Rank[1,c] + "  " + Rank[2,c] + "  " + Rank[3,c] + "  " + Rank[4,c]+ "  "+Rank[5,c]+ "  " + Rank[6,c]);
            }
        }
        //UpdateSortedPanel();
        CalcBonus(); Debug.Log("bonus calculated");
        UpdateSortedPanel();Debug.Log("Merger payout complete");
    }



    public void CloseMergerDistributionPanel()
    {
        FindFirstObjectByType<MajorityBonus>().MergerDistributionPanel.SetActive(false);
 
        FindFirstObjectByType<TwoMerger>().SixthPlayer.SetActive(true);
        FindFirstObjectByType<TwoMerger>().MSixthShare.SetActive(true);
        FindFirstObjectByType<TwoMerger>().SixthBonus.SetActive(true);
        FindFirstObjectByType<TwoMerger>().FifthPlayer.SetActive(true);
        FindFirstObjectByType<TwoMerger>().MFifthShare.SetActive(true);
        FindFirstObjectByType<TwoMerger>().FifthBonus.SetActive(true);
        FindFirstObjectByType<TwoMerger>().FourthPlayer.SetActive(true);
        FindFirstObjectByType<TwoMerger>().MFourthShare.SetActive(true);
        FindFirstObjectByType<TwoMerger>().FourthBonus.SetActive(true);        
        FindFirstObjectByType<TwoMerger>().ThirdPlayer.SetActive(true);
        FindFirstObjectByType<TwoMerger>().MThirdShare.SetActive(true);
        FindFirstObjectByType<TwoMerger>().ThirdBonus.SetActive(true);
        FindFirstObjectByType<TwoMerger>().SecondPlayer.SetActive(true);
        FindFirstObjectByType<TwoMerger>().MSecondShare.SetActive(true);
        FindFirstObjectByType<TwoMerger>().SecondBonus.SetActive(true);
    }

    public void CalcBonus()
    {
        P1MajorityBonus = 0;
        P2MajorityBonus = 0;
        P3MajorityBonus = 0;
        P4MajorityBonus = 0;
        P5MajorityBonus = 0;
        P6MajorityBonus = 0;
         
        
        int c = TwoMerger.MergerChainNumber;
        Debug.Log("                  Rank 1 is "+ShareManager.PlayerShares[RankNum[1],c]+ " "+ ShareManager.PlayerName[RankNum[1]]+"  Shares");
        Debug.Log("                  Rank 2 is "+ShareManager.PlayerShares[RankNum[2],c]+ " "+ ShareManager.PlayerName[RankNum[2]]+"  Shares");
        Debug.Log("                  Rank 3 is "+ShareManager.PlayerShares[RankNum[3],c]+ " "+ ShareManager.PlayerName[RankNum[3]]+"  Shares");
        Debug.Log("                  Rank 4 is "+ShareManager.PlayerShares[RankNum[4],c]+ " "+ ShareManager.PlayerName[RankNum[4]]+"  Shares");
        Debug.Log("                  Rank 5 is "+ShareManager.PlayerShares[RankNum[5],c]+ " "+ ShareManager.PlayerName[RankNum[5]]+"  Shares");
        Debug.Log("                  Rank 6 is "+ShareManager.PlayerShares[RankNum[6],c]+ " "+ ShareManager.PlayerName[RankNum[6]]+"  Shares");
        
       
        if(ShareManager.PlayerShares[RankNum[2],c] == 0 && ShareManager.PlayerShares[RankNum[1],c] > 0)
        {
            P1MajorityBonus = TwoMerger.MajorityBonus * 3/2;
            P2MajorityBonus = 1;
            ShareManager.PlayerCash[RankNum[1]] = ShareManager.PlayerCash[RankNum[1]] + P1MajorityBonus;
            Debug.Log("MB283   P1Majority & Minority Bonus is "+P1MajorityBonus); 
        }
        else if(ShareManager.PlayerShares[RankNum[1],c] > ShareManager.PlayerShares[RankNum[2],c])
        {
            P1MajorityBonus = TwoMerger.MajorityBonus;
            P2MajorityBonus = TwoMerger.MajorityBonus/2;
            ShareManager.PlayerCash[RankNum[1]] = ShareManager.PlayerCash[RankNum[1]] + P1MajorityBonus;
            Debug.Log("MB290  P1Majority Bonus is "+P1MajorityBonus);
            Debug.Log("MB291  P2Majority Bonus is "+P2MajorityBonus); 
        }
        else if (ShareManager.PlayerShares[RankNum[1],c] == ShareManager.PlayerShares[RankNum[2],c] && ShareManager.PlayerShares[RankNum[1],c] == ShareManager.PlayerShares[RankNum[3], c] &&
                ShareManager.PlayerShares[RankNum[1],c] == ShareManager.PlayerShares[RankNum[4],c] && ShareManager.PlayerShares[RankNum[1],c] == ShareManager.PlayerShares[RankNum[5],c] && 
                ShareManager.PlayerShares[RankNum[1],c] == ShareManager.PlayerShares[RankNum[6],c])
        {
            TwoMerger.MajorityBonus = TwoMerger.MajorityBonus/2 +TwoMerger.MajorityBonus;
            P1MajorityBonus = TwoMerger.MajorityBonus/6;
            P2MajorityBonus = TwoMerger.MajorityBonus/6;
            P3MajorityBonus = TwoMerger.MajorityBonus/6;
            P4MajorityBonus = TwoMerger.MajorityBonus/6;
            P5MajorityBonus = TwoMerger.MajorityBonus/6;
            P6MajorityBonus = TwoMerger.MajorityBonus/6;
            ShareManager.PlayerCash[RankNum[1]] = ShareManager.PlayerCash[RankNum[1]] + P1MajorityBonus;
            ShareManager.PlayerCash[RankNum[2]] = ShareManager.PlayerCash[RankNum[2]] + P2MajorityBonus;
            ShareManager.PlayerCash[RankNum[3]] = ShareManager.PlayerCash[RankNum[3]] + P3MajorityBonus;
            ShareManager.PlayerCash[RankNum[4]] = ShareManager.PlayerCash[RankNum[4]] + P4MajorityBonus;
            ShareManager.PlayerCash[RankNum[5]] = ShareManager.PlayerCash[RankNum[5]] + P5MajorityBonus;
            ShareManager.PlayerCash[RankNum[6]] = ShareManager.PlayerCash[RankNum[6]] + P6MajorityBonus;
            Debug.Log("MB all six   P1Majority Bonus is "+P1MajorityBonus); 
        }
        
        else if (ShareManager.PlayerShares[RankNum[1],c] == ShareManager.PlayerShares[RankNum[2],c] && ShareManager.PlayerShares[RankNum[1],c] == ShareManager.PlayerShares[RankNum[3], c] &&
                ShareManager.PlayerShares[RankNum[1],c] == ShareManager.PlayerShares[RankNum[4],c] && ShareManager.PlayerShares[RankNum[1],c] == ShareManager.PlayerShares[RankNum[5],c])
        {
            TwoMerger.MajorityBonus = TwoMerger.MajorityBonus/2 +TwoMerger.MajorityBonus;
            P1MajorityBonus = TwoMerger.MajorityBonus/5;
            P2MajorityBonus = TwoMerger.MajorityBonus/5;
            P3MajorityBonus = TwoMerger.MajorityBonus/5;
            P4MajorityBonus = TwoMerger.MajorityBonus/5;
            P5MajorityBonus = TwoMerger.MajorityBonus/5;
         
            ShareManager.PlayerCash[RankNum[1]] = ShareManager.PlayerCash[RankNum[1]] + P1MajorityBonus;
            ShareManager.PlayerCash[RankNum[2]] = ShareManager.PlayerCash[RankNum[2]] + P2MajorityBonus;
            ShareManager.PlayerCash[RankNum[3]] = ShareManager.PlayerCash[RankNum[3]] + P3MajorityBonus;
            ShareManager.PlayerCash[RankNum[4]] = ShareManager.PlayerCash[RankNum[4]] + P4MajorityBonus;
            ShareManager.PlayerCash[RankNum[5]] = ShareManager.PlayerCash[RankNum[5]] + P5MajorityBonus;
            Debug.Log("MB all five   P1Majority Bonus is "+P1MajorityBonus); 
        }
        else if (ShareManager.PlayerShares[RankNum[1],c] == ShareManager.PlayerShares[RankNum[2],c] && ShareManager.PlayerShares[RankNum[1],c] == ShareManager.PlayerShares[RankNum[3], c] &&
                ShareManager.PlayerShares[RankNum[1],c] == ShareManager.PlayerShares[RankNum[4],c])
        {
            TwoMerger.MajorityBonus = TwoMerger.MajorityBonus/2 +TwoMerger.MajorityBonus;
            P1MajorityBonus = TwoMerger.MajorityBonus/4;
            P2MajorityBonus = TwoMerger.MajorityBonus/4;
            P3MajorityBonus = TwoMerger.MajorityBonus/4;
            P4MajorityBonus = TwoMerger.MajorityBonus/4;

            ShareManager.PlayerCash[RankNum[1]] = ShareManager.PlayerCash[RankNum[1]] + P1MajorityBonus;
            ShareManager.PlayerCash[RankNum[2]] = ShareManager.PlayerCash[RankNum[2]] + P2MajorityBonus;
            ShareManager.PlayerCash[RankNum[3]] = ShareManager.PlayerCash[RankNum[3]] + P3MajorityBonus;
            ShareManager.PlayerCash[RankNum[4]] = ShareManager.PlayerCash[RankNum[4]] + P4MajorityBonus;
            Debug.Log("MB all four  P1Majority Bonus is "+P1MajorityBonus); 
        }
        else if (ShareManager.PlayerShares[RankNum[1],c] == ShareManager.PlayerShares[RankNum[2],c] && ShareManager.PlayerShares[RankNum[1],c] == ShareManager.PlayerShares[RankNum[3], c])
        {
            TwoMerger.MajorityBonus = TwoMerger.MajorityBonus/2 +TwoMerger.MajorityBonus;
            P1MajorityBonus = TwoMerger.MajorityBonus/3;
            P2MajorityBonus = TwoMerger.MajorityBonus/3;
            P3MajorityBonus = TwoMerger.MajorityBonus/3;

            ShareManager.PlayerCash[RankNum[1]] = ShareManager.PlayerCash[RankNum[1]] + P1MajorityBonus;
            ShareManager.PlayerCash[RankNum[2]] = ShareManager.PlayerCash[RankNum[2]] + P2MajorityBonus;
            ShareManager.PlayerCash[RankNum[3]] = ShareManager.PlayerCash[RankNum[3]] + P3MajorityBonus;
            Debug.Log("MB   1st,2nd & 3rd tied Majority Bonus is "+P1MajorityBonus);  
        }
        else if (ShareManager.PlayerShares[RankNum[1],c] == ShareManager.PlayerShares[RankNum[2],c])
        {
            TwoMerger.MajorityBonus = TwoMerger.MajorityBonus/2 +TwoMerger.MajorityBonus;
            P1MajorityBonus = TwoMerger.MajorityBonus * 1/2;
            P2MajorityBonus = TwoMerger.MajorityBonus * 1/2;
            ShareManager.PlayerCash[RankNum[1]] = ShareManager.PlayerCash[RankNum[1]] + P1MajorityBonus;
            ShareManager.PlayerCash[RankNum[2]] = ShareManager.PlayerCash[RankNum[2]] + P2MajorityBonus;
            Debug.Log("MB   1st and 2nd tied Majority Bonus is "+P1MajorityBonus);   
        }

        // MinorityShare Bonus
        if(P2MajorityBonus < 10)
        {}
        else
        {
            if(ShareManager.PlayerShares[RankNum[2],c] > ShareManager.PlayerShares[RankNum[3],c])
            {
                P2MajorityBonus = TwoMerger.MajorityBonus/2;
                ShareManager.PlayerCash[RankNum[2]] = ShareManager.PlayerCash[RankNum[2]] + P2MajorityBonus;
                Debug.Log("MB359 2nd only   P2Majority Bonus is "+P2MajorityBonus); 
            
            }
            else if (ShareManager.PlayerShares[RankNum[2],c] == ShareManager.PlayerShares[RankNum[3],c] && ShareManager.PlayerShares[RankNum[2],c] == ShareManager.PlayerShares[RankNum[4], c] &&
                ShareManager.PlayerShares[RankNum[2],c] == ShareManager.PlayerShares[RankNum[5],c] && ShareManager.PlayerShares[RankNum[2],c] == ShareManager.PlayerShares[RankNum[6],c])
            {
            P2MajorityBonus = TwoMerger.MajorityBonus/10;
            P3MajorityBonus = TwoMerger.MajorityBonus/10;
            P4MajorityBonus = TwoMerger.MajorityBonus/10;
            P5MajorityBonus = TwoMerger.MajorityBonus/10;
            P6MajorityBonus = TwoMerger.MajorityBonus/10;
            ShareManager.PlayerCash[RankNum[2]] = ShareManager.PlayerCash[RankNum[2]] + P2MajorityBonus;
            ShareManager.PlayerCash[RankNum[3]] = ShareManager.PlayerCash[RankNum[3]] + P3MajorityBonus;
            ShareManager.PlayerCash[RankNum[4]] = ShareManager.PlayerCash[RankNum[4]] + P4MajorityBonus;
            ShareManager.PlayerCash[RankNum[5]] = ShareManager.PlayerCash[RankNum[5]] + P5MajorityBonus;
            ShareManager.PlayerCash[RankNum[6]] = ShareManager.PlayerCash[RankNum[6]] + P6MajorityBonus;
            Debug.Log("MB359 Tied 2nd to 6th   P2Majority Bonus is "+P2MajorityBonus); 
            }  
            else if (ShareManager.PlayerShares[RankNum[2],c] == ShareManager.PlayerShares[RankNum[3],c] && ShareManager.PlayerShares[RankNum[2],c] == ShareManager.PlayerShares[RankNum[4], c] &&
                ShareManager.PlayerShares[RankNum[2],c] == ShareManager.PlayerShares[RankNum[5],c])
            {
            P2MajorityBonus = TwoMerger.MajorityBonus/8;
            P3MajorityBonus = TwoMerger.MajorityBonus/8;
            P4MajorityBonus = TwoMerger.MajorityBonus/8;
            P5MajorityBonus = TwoMerger.MajorityBonus/8;
            ShareManager.PlayerCash[RankNum[2]] = ShareManager.PlayerCash[RankNum[2]] + P2MajorityBonus;
            ShareManager.PlayerCash[RankNum[3]] = ShareManager.PlayerCash[RankNum[3]] + P3MajorityBonus;
            ShareManager.PlayerCash[RankNum[4]] = ShareManager.PlayerCash[RankNum[4]] + P4MajorityBonus;
            ShareManager.PlayerCash[RankNum[5]] = ShareManager.PlayerCash[RankNum[5]] + P5MajorityBonus;
             Debug.Log("MB359 Tied 2nd to 5th   P2Majority Bonus is "+P2MajorityBonus); 
            }  
            else if (ShareManager.PlayerShares[RankNum[2],c] == ShareManager.PlayerShares[RankNum[3],c] && ShareManager.PlayerShares[RankNum[2],c] == ShareManager.PlayerShares[RankNum[4], c])
            {
            P2MajorityBonus = TwoMerger.MajorityBonus/6;
            P3MajorityBonus = TwoMerger.MajorityBonus/6;
            P4MajorityBonus = TwoMerger.MajorityBonus/6;
            ShareManager.PlayerCash[RankNum[2]] = ShareManager.PlayerCash[RankNum[2]] + P2MajorityBonus;
            ShareManager.PlayerCash[RankNum[3]] = ShareManager.PlayerCash[RankNum[3]] + P3MajorityBonus;
            ShareManager.PlayerCash[RankNum[4]] = ShareManager.PlayerCash[RankNum[4]] + P4MajorityBonus;
            Debug.Log("MB359 Tied 2nd to 4th   P2Majority Bonus is "+P2MajorityBonus); 
            }  
            else if (ShareManager.PlayerShares[RankNum[2],c] == ShareManager.PlayerShares[RankNum[3],c])
            {
            P2MajorityBonus = TwoMerger.MajorityBonus/4;
            P3MajorityBonus = TwoMerger.MajorityBonus/4;
            ShareManager.PlayerCash[RankNum[2]] = ShareManager.PlayerCash[RankNum[2]] + P2MajorityBonus;
            ShareManager.PlayerCash[RankNum[3]] = ShareManager.PlayerCash[RankNum[3]] + P3MajorityBonus;
            Debug.Log("MB359 Tied 2nd to 3rd   P2Majority Bonus is "+P2MajorityBonus);  
            }  
        }

        ShareManager.PlayerCash[RankNum[3]] = ShareManager.PlayerCash[RankNum[3]] + P3MajorityBonus;
        ShareManager.PlayerCash[RankNum[4]] = ShareManager.PlayerCash[RankNum[4]] + P4MajorityBonus;
        ShareManager.PlayerCash[RankNum[5]] = ShareManager.PlayerCash[RankNum[5]] + P5MajorityBonus;
        ShareManager.PlayerCash[RankNum[5]] = ShareManager.PlayerCash[RankNum[5]] + P5MajorityBonus;
        
        UpdateSortedPanel();
        FindFirstObjectByType<Scoreboard>().Updateleaderboard();

    }
    public void UpdateSortedPanel()
    {
        if(MajorityBonus.Rank[2,TwoMerger.MergerChainNumber]==0)
        {
        FindFirstObjectByType<TwoMerger>().SecondPlayer.SetActive(false);
        FindFirstObjectByType<TwoMerger>().MSecondShare.SetActive(false);
        FindFirstObjectByType<TwoMerger>().SecondBonus.SetActive(false);
        }
        if(MajorityBonus.Rank[3,TwoMerger.MergerChainNumber]==0)
        {
        FindFirstObjectByType<TwoMerger>().ThirdPlayer.SetActive(false);
        FindFirstObjectByType<TwoMerger>().MThirdShare.SetActive(false);
        FindFirstObjectByType<TwoMerger>().ThirdBonus.SetActive(false);
        }
        if(MajorityBonus.Rank[4,TwoMerger.MergerChainNumber]==0)
        {
        FindFirstObjectByType<TwoMerger>().FourthPlayer.SetActive(false);
        FindFirstObjectByType<TwoMerger>().MFourthShare.SetActive(false);
        FindFirstObjectByType<TwoMerger>().FourthBonus.SetActive(false);
        }
         if(MajorityBonus.Rank[5,TwoMerger.MergerChainNumber]==0)
        {
        FindFirstObjectByType<TwoMerger>().FifthPlayer.SetActive(false);
        FindFirstObjectByType<TwoMerger>().MFifthShare.SetActive(false);
        FindFirstObjectByType<TwoMerger>().FifthBonus.SetActive(false);
        }
         if(MajorityBonus.Rank[6,TwoMerger.MergerChainNumber]==0)
        {
        FindFirstObjectByType<TwoMerger>().SixthPlayer.SetActive(false);
        FindFirstObjectByType<TwoMerger>().MSixthShare.SetActive(false);
        FindFirstObjectByType<TwoMerger>().SixthBonus.SetActive(false);
        }
        
        // Updating Names
    
        FindObjectOfType<TwoMerger>().FirstPlayer.GetComponentInChildren<Text>().text = MajorityBonus.RankPlayer[1];
        FindObjectOfType<TwoMerger>().SecondPlayer.GetComponentInChildren<Text>().text = MajorityBonus.RankPlayer[2];
        FindObjectOfType<TwoMerger>().ThirdPlayer.GetComponentInChildren<Text>().text = MajorityBonus.RankPlayer[3];
        FindObjectOfType<TwoMerger>().FourthPlayer.GetComponentInChildren<Text>().text = MajorityBonus.RankPlayer[4];
        FindObjectOfType<TwoMerger>().FifthPlayer.GetComponentInChildren<Text>().text = MajorityBonus.RankPlayer[5];
        FindObjectOfType<TwoMerger>().SixthPlayer.GetComponentInChildren<Text>().text = MajorityBonus.RankPlayer[6];

        // Updating Shares (working)
        
        FindObjectOfType<TwoMerger>().MFirstShare.GetComponentInChildren<Text>().text = MajorityBonus.Rank[1,TwoMerger.MergerChainNumber].ToString();
        FindObjectOfType<TwoMerger>().MSecondShare.GetComponentInChildren<Text>().text = MajorityBonus.Rank[2,TwoMerger.MergerChainNumber].ToString();
        FindObjectOfType<TwoMerger>().MThirdShare.GetComponentInChildren<Text>().text = MajorityBonus.Rank[3,TwoMerger.MergerChainNumber].ToString();
        FindObjectOfType<TwoMerger>().MFourthShare.GetComponentInChildren<Text>().text = MajorityBonus.Rank[4,TwoMerger.MergerChainNumber].ToString();
        FindObjectOfType<TwoMerger>().MFifthShare.GetComponentInChildren<Text>().text = MajorityBonus.Rank[5,TwoMerger.MergerChainNumber].ToString();
        FindObjectOfType<TwoMerger>().MSixthShare.GetComponentInChildren<Text>().text = MajorityBonus.Rank[6,TwoMerger.MergerChainNumber].ToString();

        // Updating Amount
        FindFirstObjectByType<TwoMerger>().FirstBonus.GetComponentInChildren<Text>().text = P1MajorityBonus.ToString("$##,##0");
        FindFirstObjectByType<TwoMerger>().SecondBonus.GetComponentInChildren<Text>().text = P2MajorityBonus.ToString("$##,##0");
        FindFirstObjectByType<TwoMerger>().ThirdBonus.GetComponentInChildren<Text>().text = P3MajorityBonus.ToString("$##,##0");
        FindFirstObjectByType<TwoMerger>().FourthBonus.GetComponentInChildren<Text>().text = P4MajorityBonus.ToString("$##,##0");
        FindFirstObjectByType<TwoMerger>().FifthBonus.GetComponentInChildren<Text>().text = P5MajorityBonus.ToString("$##,##0");
        FindFirstObjectByType<TwoMerger>().SixthBonus.GetComponentInChildren<Text>().text = P6MajorityBonus.ToString("$##,##0");
        


        Debug.Log("UpdateSortedPanel Completed");
    }

    public void MergerAftermath()
    {
        CloseMergerDistributionPanel();

    }

}


