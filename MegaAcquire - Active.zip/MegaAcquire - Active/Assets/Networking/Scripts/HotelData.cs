using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HotelData : MonoBehaviour
{
  

    static public int HotelCount=0;  static public int MaxHotel = 4;
  
    public GameObject LuxorButton;
    public GameObject GlobalButton;
    public GameObject ArcadiaButton;
    public GameObject RegalButton;

    public static bool GameBoardActive = true;

    public GameObject LuxorHotel;
    public GameObject GlobalHotel;
    public GameObject RegalHotel;
    public GameObject ArcadiaHotel;
    
    public static int HotelNum;
    public static string[] HotelName;
    public static int[] HotelShareCounter;
    public static int[] ChainId;   
    public static int[] HotelActive;
    public static int[] HotelFounder;
    static public int[,] ChainData;
    static public int[] ChainSize;
    public int ChainNum = 0;
    //public bool[] HotelActive;
  // move to sharemanae
    
    

    

    public void Start()
    {
        HotelFounder = new int[15];
        for (int i = 1; i < 15; i++) { HotelFounder[i] = 0; }
        ShareManager.PlayerCash = new int[8];
        for (int i = 0; i < 8; i++) { ShareManager.PlayerCash[i] = 12000; };
        HotelShareCounter = new int[15];
        for (int i = 1; i < 15; i++) { HotelShareCounter[i] = 25; }
        
        ShareManager.PlayerShares = new int[8, 15];
        for (int a = 0; a < 8; a++)
        {
          for (int b = 0; b < 15; b++) 
          { 
            ShareManager.PlayerShares[a, b] = 0; 
          }
        }
        HotelName = new string[15];
        HotelName[1] = "Luxor";HotelName[5] = "Global";HotelName[7] = "Arcadia";HotelName[11] = "Regal";

        ChainData = new int[15, 175];

        ChainData[1, 2] = 200; ChainData[1, 3] = 300; ChainData[1, 4] = 400; ChainData[1, 5] = 500;
        for (int i = 6; i< 11; i++) { ChainData[1, i] = 600;}
        for (int i = 11; i < 21; i++) { ChainData[1, i] = 700;}
        for (int i = 21; i < 31; i++) { ChainData[1, i] = 800; }
        for (int i = 31; i < 41; i++) { ChainData[1, i] = 900; }
        for (int i = 41; i < 61; i++) { ChainData[1, i] = 1000; }
        for (int i = 61; i < 81; i++) { ChainData[1, i] = 1100; }
        for (int i = 81; i < 101; i++) { ChainData[1, i] = 1200; }
        for (int i = 101; i < 175; i++) { ChainData[1, i] = 1300; }

        ChainData[5, 2] = 300; ChainData[5, 3] = 400; ChainData[5, 4] = 500; ChainData[5, 5] = 600;
        for (int i = 6; i < 11; i++) { ChainData[5, i] = 700; }
        for (int i = 11; i < 21; i++) { ChainData[5, i] = 800; }
        for (int i = 21; i < 31; i++) { ChainData[5, i] = 900; }
        for (int i = 31; i < 41; i++) { ChainData[5, i] = 1000; }
        for (int i = 41; i < 61; i++) { ChainData[5, i] = 1100; }
        for (int i = 61; i < 81; i++) { ChainData[5, i] = 1200; }
        for (int i = 81; i < 101; i++) { ChainData[5, i] = 1300; }
        for (int i = 101; i < 175; i++) { ChainData[5, i] = 1400; }

        ChainData[7, 2] = 300; ChainData[7, 3] = 400; ChainData[7, 4] = 500; ChainData[7, 5] = 600;
        for (int i = 6; i < 11; i++) { ChainData[7, i] = 700; }
        for (int i = 11; i < 21; i++) { ChainData[7, i] = 800; }
        for (int i = 21; i < 31; i++) { ChainData[7, i] = 900; }
        for (int i = 31; i < 41; i++) { ChainData[7, i] = 1000; }
        for (int i = 41; i < 61; i++) { ChainData[7, i] = 1100; }
        for (int i = 61; i < 81; i++) { ChainData[7, i] = 1200; }
        for (int i = 81; i < 101; i++) { ChainData[7, i] = 1300; }
        for (int i = 101; i < 175; i++) { ChainData[7, i] = 1400; }

        ChainData[11, 2] = 400; ChainData[11, 3] = 500; ChainData[11, 4] = 600; ChainData[11, 5] = 700;
        for (int i = 6; i < 11; i++) { ChainData[11, i] = 800; }
        for (int i = 11; i < 21; i++) { ChainData[11, i] = 900; }
        for (int i = 21; i < 31; i++) { ChainData[11, i] = 1000; }
        for (int i = 31; i < 41; i++) { ChainData[11, i] = 1100; }
        for (int i = 41; i < 61; i++) { ChainData[11, i] = 1200; }
        for (int i = 61; i < 81; i++) { ChainData[11, i] = 1300; }
        for (int i = 81; i < 101; i++) { ChainData[11, i] = 1400; }
        for (int i = 101; i < 175; i++) { ChainData[11, i] = 1500; }

        MajorityBonus.MergerPlayerShares = new int[6];
      
        ShareManager.PlayerShares = new int[8, 15];
        for (int a = 0; a < 8; a++)
        {
          for (int b = 0; b < 15; b++) 
          { 
            ShareManager.PlayerShares[a, b] = 0; 
          }
        }
        ShareManager.PlayerValue = new int [7];
        for (int i = 0; i < 7; i++) {ShareManager.PlayerValue[i] = 12000;}

        ChainSize = new int[15]; 
        for (int i = 0; i < 15; i++) {ChainSize[i] = 0;}
   
        HotelData.HotelActive = new int[15];
        for (int i = 1; i < 15; i++) { HotelData.HotelActive[i] = 1; }
                
    



    }

    public void Luxor()
    {
        HotelNum = 1;
        if(HotelShareCounter[HotelNum] > 0){HotelFounder[HotelNum] = 1;}
        if(HotelActive[1]==1)
        {
          HotelActive[1] = 0;
         
        }
        LuxorButton.SetActive(false); // Debug.Log("Luxor Start Button Not Active"); 
    }
    public void Global()
    {
        HotelNum = 5;
        if(HotelShareCounter[HotelNum] >0){HotelFounder[HotelNum] = 1;}
        GlobalButton.SetActive(false); // Debug.Log("Global Start Button Not Active"); 
        }
    public void Arcadia()
    {
        HotelNum = 7;
        if(HotelShareCounter[HotelNum] >0){HotelFounder[HotelNum] = 1;}
        ArcadiaButton.SetActive(false); // Debug.Log("Arcadia Start Button Not Active"); 
    }
    public void Regal()
    {
        HotelNum = 11;
        if(HotelShareCounter[HotelNum] >0){HotelFounder[HotelNum] = 1;}
        RegalButton.SetActive(false); // Debug.Log("Regal Start Button Not Active"); 
    }

}
