using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class ShareManager : MonoBehaviour
{
    [Header("Panel Information")]
    //public GameObject SharePurchasePanel;    
    //public GameObject PlaceTilePanel;
    
    [Header("Player Info")]
    public static int[] PlayerCash;
    static public int[,] PlayerShares;
    static public string [] PlayerName;
    public static int[] PlayerValue;
    public GameObject PlayerNameTurnDisplay; 
    public GameObject Player1Highlight;public GameObject Player2Highlight;public GameObject Player3Highlight;
    public GameObject Player1Display; public GameObject Player2Display;public GameObject Player3Display;
    public int GamePlayer = 1;
 

    [Header("Share Purchase Info")]
    public int SharePrice; public float SharePurchase;public GameObject SharePurchaseTotal;
     public int HotelShares; public int HotelShareCount; public GameObject ActionDisplay;
    public GameObject BuyShare1;public GameObject BuyShare2;public GameObject BuyShare3;
    public GameObject BuyShare4;public GameObject BuyShare5;public GameObject BuyShare6;
    public GameObject BuyShare1Text;public GameObject BuyShare2Text;public GameObject BuyShare3Text;
    public GameObject BuyShare4Text;public GameObject BuyShare5Text;public GameObject BuyShare6Text;
    public int ShareNum1 = 1;public int ShareNum2 = 0;public int ShareNum3 = 0;
    public int ShareNum4 = 0;public int ShareNum5 = 0;public int ShareNum6 = 0;
    public static int SellOne;public static int SellTwo;public static int SellThree;
    public static int SellFour;public static int SellFive;public static int SellSix;



    void Start()
    {
        PlayerName = new string[7];

        PlayerName[1] = "Adam";
        PlayerName[2] = "Matthew";  
        PlayerName[3] = "Ben";  
        PlayerName[4] = "Eden";  
        PlayerName[5] = "Andrew";  
        PlayerName[6] = "Ian";
    }

    public void LocateLuxor()
    {
        OpenSharePurchasePanel();
        SharePrice = HotelData.ChainData[1, HotelData.ChainSize[1]];
        FindObjectOfType<Scoreboard>().LuxorShareBalanceDisplay.GetComponent<Text>().text = HotelData.HotelShareCounter[1].ToString();
        ActionDisplay.GetComponent<Text>().text = " ";
            
        // Checking to see if cash or shares are in the bank
        
        if (HotelData.HotelShareCounter[1] > 0)
        {
            BuyShareRoutine();
        }
        else if (HotelData.HotelShareCounter[1] == 0)
        {
            ActionDisplay.GetComponent<Text>().text = "No More Shares";Debug.Log("Hotel shares are: "+HotelData.HotelShareCounter[1]);
        }
    }
    public void BuyShareRoutine()
    {
        
        ActionDisplay.GetComponent<Text>().text = " ";

        if (HotelData.HotelShareCounter[HotelData.HotelNum] > 0)
        {
            if (HotelShareCount == 6)
            {
                Debug.Log("Buy too many shares - Hotel is "+HotelData.HotelNum+"  HotelShareCounter is: "+HotelData.HotelShareCounter[HotelData.HotelNum]);
                FindObjectOfType<Scoreboard>().Updateleaderboard();
            }
            else if (ShareNum1 == 1 && HotelShareCount < 6)
            {
                BuyFirstShare();
                //Debug.Log("Buy 1st Share - Hotel is "+HotelData.HotelName[HotelData.HotelNum]+"  HotelShareCounter is: "+HotelData.HotelShareCounter[HotelData.HotelNum]);
            }
            else if (ShareNum2 == 1 && HotelShareCount < 6)
            {
                BuySecondShare();
                //Debug.Log("Buy 2nd Share - Hotel is "+HotelData.HotelName[HotelData.HotelNum]+"  HotelShareCounter is: "+HotelData.HotelShareCounter[HotelData.HotelNum]);
            }
            else if (ShareNum3 == 1 && HotelShareCount < 6)
            {
                BuyThirdShare();
                //Debug.Log("Buy 3rd Share - Hotel is "+HotelData.HotelName[HotelData.HotelNum]+"  HotelShareCounter is: "+HotelData.HotelShareCounter[HotelData.HotelNum]);
            }
            else if (ShareNum4 == 1 && HotelShareCount < 6)
            {
                BuyFourthShare();
                //Debug.Log("Buy 4th Share - Hotel is "+HotelData.HotelName[HotelData.HotelNum]+"  HotelShareCounter is: "+HotelData.HotelShareCounter[HotelData.HotelNum]);
            }
            else if (ShareNum5 == 1 && HotelShareCount < 6)
            {
                BuyFifthShare();
                //Debug.Log("Buy 5th Share - Hotel is "+HotelData.HotelName[HotelData.HotelNum]+"  HotelShareCounter is: "+HotelData.HotelShareCounter[HotelData.HotelNum]);
            }
            else if (ShareNum6 == 1 && HotelShareCount < 6)
            {
                BuySixthShare();
                Debug.Log("Buy 6th Share - Hotel is "+HotelData.HotelNum+"  HotelShareCounter is: "+HotelData.HotelShareCounter[HotelData.HotelNum]);
                ActionDisplay.GetComponent<Text>().text = "6 shares maximum";
            }
            if (HotelShareCount == 6)
            {
                ActionDisplay.GetComponent<Text>().text = "6 shares maximum"; Debug.Log("6 share maximum");
                FindObjectOfType<Scoreboard>().Updateleaderboard();
            }
        }
    }
    public void BuyFirstShare()
    {
        // Cycling through share purchases begining with the first share

        if (ShareManager.PlayerCash[GamePlayer] >= SharePrice)
        {
            if (HotelData.HotelNum == 1)
            {
                Color newColor11 = new Color(230 / 255f, 230 / 255f, 105 / 255f);  // Luxor Colour
                BuyShare1.GetComponent<Image>().color = newColor11;
                BuyShare1Text.GetComponent<Text>().text = SharePrice.ToString();
                HotelData.HotelShareCounter[1] = HotelData.HotelShareCounter[1] - 1 ;
                FindObjectOfType<Scoreboard>().LuxorShareBalanceDisplay.GetComponent<Text>().text = HotelData.HotelShareCounter[1].ToString();

            }
            if (HotelData.HotelNum == 5)
            {
                Color newColor51 = new Color(240 / 255f, 135 / 255f, 20 / 255f);  // Global Colour
                BuyShare1.GetComponent<Image>().color = newColor51;
                BuyShare1Text.GetComponent<Text>().text = SharePrice.ToString();
                HotelData.HotelShareCounter[5] = HotelData.HotelShareCounter[5] - 1 ;
                FindObjectOfType<Scoreboard>().GlobalShareBalanceDisplay.GetComponent<Text>().text = HotelData.HotelShareCounter[5].ToString();
            }
            if (HotelData.HotelNum == 7)
            {
                Color newColor71 = new Color(125/ 255f, 130 / 255f, 225 / 255f);  // Arcadia Colour
                BuyShare1.GetComponent<Image>().color = newColor71;
                BuyShare1Text.GetComponent<Text>().text = SharePrice.ToString(); BuyShare1Text.GetComponent<Text>().color = Color.white;
                HotelData.HotelShareCounter[7] = HotelData.HotelShareCounter[7] - 1 ;
                FindObjectOfType<Scoreboard>().ArcadiaShareBalanceDisplay.GetComponent<Text>().text = HotelData.HotelShareCounter[7].ToString();
            }
            if (HotelData.HotelNum == 11)
            {
                Color newColor111 = new Color(80 / 255f, 40 / 255f, 160 / 255f);  // Regal Colour
                BuyShare1.GetComponent<Image>().color = newColor111;
                BuyShare1Text.GetComponent<Text>().text = SharePrice.ToString(); BuyShare1Text.GetComponent<Text>().color = Color.white;
                HotelData.HotelShareCounter[11] = HotelData.HotelShareCounter[11] - 1 ;
                FindObjectOfType<Scoreboard>().RegalShareBalanceDisplay.GetComponent<Text>().text = HotelData.HotelShareCounter[11].ToString();
            }
        
            BuyIndividualSharesRoutine();
            SellOne=HotelData.HotelNum;
            Debug.Log("HotelData.HotelNum is: "+HotelData.HotelNum);
            Debug.Log("Sell Share " +SellOne + "  " + SellTwo+"  " + SellThree + "  " +SellFour + "  " +SellFive + "  " +SellSix);
            ShareNum1 = 0;
            ShareNum2 = 1;
           
        }
        HotelShareCount ++;
        FindObjectOfType<Scoreboard>().Updateleaderboard();
    }
    public void BuySecondShare()
    {
        //SharePurchaseNumber = SharePurchaseNumber + 1;
        if (ShareManager.PlayerCash[GamePlayer] >= SharePrice)
        {
            if (HotelData.HotelNum == 1)
            {
                Color newColor12 = new Color(230 / 255f, 230 / 255f, 105 / 255f);
                BuyShare2.GetComponent<Image>().color = newColor12;
                BuyShare2Text.GetComponent<Text>().text = SharePrice.ToString();
                HotelData.HotelShareCounter[1] = HotelData.HotelShareCounter[1] - 1 ;
                FindObjectOfType<Scoreboard>().LuxorShareBalanceDisplay.GetComponent<Text>().text = HotelData.HotelShareCounter[1].ToString();
            }
            if (HotelData.HotelNum == 5)
            {
                Color newColor52 = new Color(240 / 255f, 135 / 255f, 20 / 255f);
                BuyShare2.GetComponent<Image>().color = newColor52;
                BuyShare2Text.GetComponent<Text>().text = SharePrice.ToString();
                HotelData.HotelShareCounter[5] = HotelData.HotelShareCounter[5] - 1 ;
                FindObjectOfType<Scoreboard>().GlobalShareBalanceDisplay.GetComponent<Text>().text = HotelData.HotelShareCounter[5].ToString();
            }
            if (HotelData.HotelNum == 7)
            {
                Color newColor71 = new Color(125/ 255f, 130 / 255f, 225 / 255f);  // Arcadia Colour
                BuyShare2.GetComponent<Image>().color = newColor71;
                BuyShare2Text.GetComponent<Text>().text = SharePrice.ToString(); BuyShare2Text.GetComponent<Text>().color = Color.white;
                HotelData.HotelShareCounter[7] = HotelData.HotelShareCounter[7] - 1 ;
                FindObjectOfType<Scoreboard>().ArcadiaShareBalanceDisplay.GetComponent<Text>().text = HotelData.HotelShareCounter[7].ToString();
            }
            if (HotelData.HotelNum == 11)
            {
                Color newColor112 = new Color(80 / 255f, 40 / 255f, 160 / 255f);
                BuyShare2.GetComponent<Image>().color = newColor112;
                BuyShare2Text.GetComponent<Text>().text = SharePrice.ToString(); BuyShare2Text.GetComponent<Text>().color = Color.white;
                HotelData.HotelShareCounter[11] = HotelData.HotelShareCounter[11] - 1 ;
                FindObjectOfType<Scoreboard>().RegalShareBalanceDisplay.GetComponent<Text>().text = HotelData.HotelShareCounter[11].ToString();
            }
            BuyIndividualSharesRoutine();
            SellTwo=HotelData.HotelNum;
            Debug.Log("HotelData.HotelNum is: "+HotelData.HotelNum);
            Debug.Log("Sell Share " +SellOne + "  " + SellTwo+"  " + SellThree + "  " +SellFour + "  " +SellFive + "  " +SellSix);
            ShareNum1 = 0;
            ShareNum2 = 0;
            ShareNum3 = 1;
        }
        HotelShareCount= HotelShareCount + 1;
         FindObjectOfType<Scoreboard>().Updateleaderboard();
             }
    public void BuyThirdShare()
    {
        //SharePurchaseNumber = SharePurchaseNumber + 1;
        if (ShareManager.PlayerCash[GamePlayer] >= SharePrice)
        {
            if (HotelData.HotelNum == 1)
            {
                Color newColor13 = new Color(230 / 255f, 230 / 255f, 105 / 255f);
                BuyShare3.GetComponent<Image>().color = newColor13;
                BuyShare3Text.GetComponent<Text>().text = SharePrice.ToString();
                HotelData.HotelShareCounter[1] = HotelData.HotelShareCounter[1] - 1 ;
                FindObjectOfType<Scoreboard>().LuxorShareBalanceDisplay.GetComponent<Text>().text = HotelData.HotelShareCounter[1].ToString();
            }
            if (HotelData.HotelNum == 5)
            {
                Color newColor53 = new Color(240 / 255f, 135 / 255f, 20 / 255f);
                BuyShare3.GetComponent<Image>().color = newColor53;
                BuyShare3Text.GetComponent<Text>().text = SharePrice.ToString();
                HotelData.HotelShareCounter[5] = HotelData.HotelShareCounter[5] - 1 ;
                FindObjectOfType<Scoreboard>().GlobalShareBalanceDisplay.GetComponent<Text>().text = HotelData.HotelShareCounter[5].ToString();
            }
            if (HotelData.HotelNum == 7)
            {
                Color newColor71 = new Color(125/ 255f, 130 / 255f, 225 / 255f);  // Arcadia Colour
                BuyShare3.GetComponent<Image>().color = newColor71;
                BuyShare3Text.GetComponent<Text>().text = SharePrice.ToString(); BuyShare3Text.GetComponent<Text>().color = Color.white;
                HotelData.HotelShareCounter[7] = HotelData.HotelShareCounter[7] - 1 ;
                FindObjectOfType<Scoreboard>().ArcadiaShareBalanceDisplay.GetComponent<Text>().text = HotelData.HotelShareCounter[7].ToString();
            }
            if (HotelData.HotelNum == 11)
            {
                Color newColor113 = new Color(80 / 255f, 40 / 255f, 160 / 255f);
                BuyShare3.GetComponent<Image>().color = newColor113;
                BuyShare3Text.GetComponent<Text>().text = SharePrice.ToString(); BuyShare3Text.GetComponent<Text>().color = Color.white;
                HotelData.HotelShareCounter[11] = HotelData.HotelShareCounter[11] - 1 ;
                FindObjectOfType<Scoreboard>().RegalShareBalanceDisplay.GetComponent<Text>().text = HotelData.HotelShareCounter[11].ToString();
            }
            BuyIndividualSharesRoutine();
            SellThree=HotelData.HotelNum;
            Debug.Log("Sell Share " +SellOne + "  " + SellTwo+"  " + SellThree + "  " +SellFour + "  " +SellFive + "  " +SellSix);
            ShareNum1 = 0;
            ShareNum2 = 0;
            ShareNum3 = 0;
            ShareNum4 = 1;
        }
        HotelShareCount ++;
        FindObjectOfType<Scoreboard>().Updateleaderboard();
    }
    public void BuyFourthShare()
    {
        //SharePurchaseNumber = SharePurchaseNumber + 1;
        if (ShareManager.PlayerCash[GamePlayer] >= SharePrice)
        {
            if (HotelData.HotelNum == 1)
            {
                Color newColor14 = new Color(230 / 255f, 230 / 255f, 105 / 255f);
                BuyShare4.GetComponent<Image>().color = newColor14;
                BuyShare4Text.GetComponent<Text>().text = SharePrice.ToString();
                HotelData.HotelShareCounter[1] = HotelData.HotelShareCounter[1] - 1 ;
               FindObjectOfType<Scoreboard>().LuxorShareBalanceDisplay.GetComponent<Text>().text = HotelData.HotelShareCounter[1].ToString();
            }
            if (HotelData.HotelNum == 5)
            {
                Color newColor54 = new Color(240 / 255f, 135 / 255f, 20 / 255f);
                BuyShare4.GetComponent<Image>().color = newColor54;
                BuyShare4Text.GetComponent<Text>().text = SharePrice.ToString();
                HotelData.HotelShareCounter[5] = HotelData.HotelShareCounter[5] - 1 ;
                FindObjectOfType<Scoreboard>().GlobalShareBalanceDisplay.GetComponent<Text>().text = HotelData.HotelShareCounter[5].ToString();
            }
            if (HotelData.HotelNum == 7)
            {
                Color newColor71 = new Color(125/ 255f, 130 / 255f, 225 / 255f);  // Arcadia Colour
                BuyShare4.GetComponent<Image>().color = newColor71;
                BuyShare4Text.GetComponent<Text>().text = SharePrice.ToString(); BuyShare4Text.GetComponent<Text>().color = Color.white;
                HotelData.HotelShareCounter[7] = HotelData.HotelShareCounter[7] - 1 ;
                FindObjectOfType<Scoreboard>().ArcadiaShareBalanceDisplay.GetComponent<Text>().text = HotelData.HotelShareCounter[7].ToString();
            }
            if (HotelData.HotelNum == 11)
            {
                Color newColor114 = new Color(80 / 255f, 40 / 255f, 160 / 255f);
                BuyShare4.GetComponent<Image>().color = newColor114;
                BuyShare4Text.GetComponent<Text>().text = SharePrice.ToString(); BuyShare4Text.GetComponent<Text>().color = Color.white;
                HotelData.HotelShareCounter[11] = HotelData.HotelShareCounter[11] - 1 ;
                FindObjectOfType<Scoreboard>().RegalShareBalanceDisplay.GetComponent<Text>().text = HotelData.HotelShareCounter[11].ToString();
            }
        
            BuyIndividualSharesRoutine();
            SellFour=HotelData.HotelNum;
            Debug.Log("Sell Share " +SellOne + "  " + SellTwo+"  " + SellThree + "  " +SellFour + "  " +SellFive + "  " +SellSix);
            ShareNum1 = 0;
            ShareNum2 = 0;
            ShareNum3 = 0;
            ShareNum4 = 0;
            ShareNum5 = 1;
        }
        HotelShareCount ++;
         FindObjectOfType<Scoreboard>().Updateleaderboard();
    }
    public void BuyFifthShare()
    {
        if (ShareManager.PlayerCash[GamePlayer] >= SharePrice)
        {
            if (HotelData.HotelNum == 1)
            {
                Color newColor15 = new Color(230 / 255f, 230 / 255f, 105 / 255f);
                BuyShare5.GetComponent<Image>().color = newColor15;
                BuyShare5Text.GetComponent<Text>().text = SharePrice.ToString();
                HotelData.HotelShareCounter[1] = HotelData.HotelShareCounter[1] - 1 ;
                FindObjectOfType<Scoreboard>().LuxorShareBalanceDisplay.GetComponent<Text>().text = HotelData.HotelShareCounter[1].ToString();
            }
            if (HotelData.HotelNum == 5)
            {
                Color newColor55 = new Color(240 / 255f, 135 / 255f, 20 / 255f);
                BuyShare5.GetComponent<Image>().color = newColor55;
                BuyShare5Text.GetComponent<Text>().text = SharePrice.ToString();
                HotelData.HotelShareCounter[5] = HotelData.HotelShareCounter[5] - 1 ;
                FindObjectOfType<Scoreboard>().GlobalShareBalanceDisplay.GetComponent<Text>().text = HotelData.HotelShareCounter[5].ToString();
            }
            if (HotelData.HotelNum == 7)
            {
                Color newColor71 = new Color(125/ 255f, 130 / 255f, 225 / 255f);  // Arcadia Colour
                BuyShare5.GetComponent<Image>().color = newColor71;
                BuyShare5Text.GetComponent<Text>().text = SharePrice.ToString(); BuyShare5Text.GetComponent<Text>().color = Color.white;
                HotelData.HotelShareCounter[7] = HotelData.HotelShareCounter[7] - 1 ;
                FindObjectOfType<Scoreboard>().ArcadiaShareBalanceDisplay.GetComponent<Text>().text = HotelData.HotelShareCounter[7].ToString();
            }
            if (HotelData.HotelNum == 11)
            {
                Color newColor115 = new Color(80 / 255f, 40 / 255f, 160 / 255f);
                BuyShare5.GetComponent<Image>().color = newColor115;
                BuyShare5Text.GetComponent<Text>().text = SharePrice.ToString(); BuyShare5Text.GetComponent<Text>().color = Color.white;
                HotelData.HotelShareCounter[11] = HotelData.HotelShareCounter[11] - 1 ;
                FindObjectOfType<Scoreboard>().RegalShareBalanceDisplay.GetComponent<Text>().text = HotelData.HotelShareCounter[11].ToString();
            }

            BuyIndividualSharesRoutine();
            SellFive=HotelData.HotelNum;
            Debug.Log("Sell Share " +SellOne + "  " + SellTwo+"  " + SellThree + "  " +SellFour + "  " +SellFive + "  " +SellSix);
            ShareNum1 = 0;
            ShareNum2 = 0;
            ShareNum3 = 0;
            ShareNum4 = 0;
            ShareNum5 = 0;
            ShareNum6 = 1;
        }
        HotelShareCount ++;
        FindObjectOfType<Scoreboard>().Updateleaderboard();
    }
    public void BuySixthShare()
    {
    
        if (ShareManager.PlayerCash[GamePlayer] >= SharePrice)
        {
            if (HotelData.HotelNum == 1)
            {
                Color newColor16 = new Color(230 / 255f, 230 / 255f, 105 / 255f);
                BuyShare6.GetComponent<Image>().color = newColor16;
                BuyShare6Text.GetComponent<Text>().text = SharePrice.ToString();
                HotelData.HotelShareCounter[1] = HotelData.HotelShareCounter[1] - 1 ;
                FindObjectOfType<Scoreboard>().LuxorShareBalanceDisplay.GetComponent<Text>().text = HotelData.HotelShareCounter[1].ToString();
            }
            if (HotelData.HotelNum == 5)
            {
                Color newColor56 = new Color(240 / 255f, 135 / 255f, 20 / 255f);
                BuyShare6.GetComponent<Image>().color = newColor56;
                BuyShare6Text.GetComponent<Text>().text = SharePrice.ToString();
                HotelData.HotelShareCounter[5] = HotelData.HotelShareCounter[5] - 1 ;
                FindObjectOfType<Scoreboard>().GlobalShareBalanceDisplay.GetComponent<Text>().text = HotelData.HotelShareCounter[5].ToString();
            }
            if (HotelData.HotelNum == 7)
            {
                Color newColor71 = new Color(125/ 255f, 130 / 255f, 225 / 255f);  // Arcadia Colour
                BuyShare6.GetComponent<Image>().color = newColor71;
                BuyShare6Text.GetComponent<Text>().text = SharePrice.ToString(); BuyShare6Text.GetComponent<Text>().color = Color.white;
                HotelData.HotelShareCounter[7] = HotelData.HotelShareCounter[7] - 1 ;
                FindObjectOfType<Scoreboard>().ArcadiaShareBalanceDisplay.GetComponent<Text>().text = HotelData.HotelShareCounter[7].ToString();
            }
            if (HotelData.HotelNum == 11)
            {
                Color newColor116 = new Color(80 / 255f, 40 / 255f, 160 / 255f);
                BuyShare6.GetComponent<Image>().color = newColor116;
                BuyShare6Text.GetComponent<Text>().text = SharePrice.ToString(); BuyShare6Text.GetComponent<Text>().color = Color.white;
                HotelData.HotelShareCounter[11] = HotelData.HotelShareCounter[11] - 1 ;
                FindObjectOfType<Scoreboard>().RegalShareBalanceDisplay.GetComponent<Text>().text = HotelData.HotelShareCounter[11].ToString();
            }
            
            BuyIndividualSharesRoutine();
            SellSix=HotelData.HotelNum;
            Debug.Log("Sell Share " +SellOne + "  " + SellTwo+"  " + SellThree + "  " +SellFour + "  " +SellFive + "  " +SellSix);
            ShareNum1 = 0;
            ShareNum2 = 0;
            ShareNum3 = 0;
            ShareNum4 = 0;
            ShareNum5 = 0; 
            ShareNum6 = 1;
        }
       
        HotelShareCount ++;

         FindObjectOfType<Scoreboard>().Updateleaderboard();
        
                
    }
    
    public void SellFirstShare()
    {
        if(SellOne==0)
        {}
        else 
        {
            ShareManager.PlayerShares[GamePlayer, SellOne] = ShareManager.PlayerShares[GamePlayer, SellOne] - 1;
            HotelData.HotelShareCounter[SellOne] = HotelData.HotelShareCounter[SellOne] +1;
            Debug.Log("SellOne = "+SellOne+"  HotelShare = "+ HotelData.HotelShareCounter[SellOne] );
            BuyShare1.GetComponent<Image>().color = Color.white;
            BuyShare1Text.GetComponent<Text>().text = "1"; BuyShare1Text.GetComponent<Text>().color = Color.black;
            SharePrice = HotelData.ChainData[SellOne,HotelData.ChainSize[SellOne]];
            SellIndividualSharesRoutine();
            SellOne=0;
            ShareNum1 = 1;
            HotelShareCount --;
            Debug.Log("Sell Share " +SellOne + "  " + SellTwo+"  " + SellThree + "  " +SellFour + "  " +SellFive + "  " +SellSix);
            FindObjectOfType<Scoreboard>().Updateleaderboard();
        }
    }
    public void SellSecondShare()
    {
        if(SellTwo==0)
        {}
        else
        {
            ShareManager.PlayerShares[GamePlayer, SellTwo] = ShareManager.PlayerShares[GamePlayer, SellTwo] - 1;
            HotelData.HotelShareCounter[SellTwo] = HotelData.HotelShareCounter[SellTwo] + 1;
            Debug.Log("SellTwo = "+SellTwo+"  HotelShare = "+ HotelData.HotelShareCounter[SellTwo] );
            BuyShare2.GetComponent<Image>().color = Color.white;
            BuyShare2Text.GetComponent<Text>().text = "2"; BuyShare2Text.GetComponent<Text>().color = Color.black;
            SharePrice = HotelData.ChainData[SellTwo,HotelData.ChainSize[SellTwo]];
            SellIndividualSharesRoutine();
            SellTwo=0;
            ShareNum2 = 1;
            HotelShareCount --;
            Debug.Log("Sell Share " +SellOne + "  " + SellTwo+"  " + SellThree + "  " +SellFour + "  " +SellFive + "  " +SellSix);
            FindObjectOfType<Scoreboard>().Updateleaderboard();
        }
    }
    public void SellThirdShare()
    {
        if(SellThree==0)
        {}
        else
        {
            ShareManager.PlayerShares[GamePlayer, SellThree] = ShareManager.PlayerShares[GamePlayer, SellThree] - 1;
            Debug.Log("SellThree = "+SellThree+"  HotelShare = "+ HotelData.HotelShareCounter[SellThree] );
            HotelData.HotelShareCounter[SellThree] = HotelData.HotelShareCounter[SellThree] + 1;
            Debug.Log("SellThree = "+SellThree+"  HotelShare = "+ HotelData.HotelShareCounter[SellThree] );
            BuyShare3.GetComponent<Image>().color = Color.white;
            BuyShare3Text.GetComponent<Text>().text = "3"; BuyShare3Text.GetComponent<Text>().color = Color.black;
            SharePrice = HotelData.ChainData[SellThree,HotelData.ChainSize[SellThree]];
            SellIndividualSharesRoutine();
            SellThree=0;
            ShareNum3 = 1;
            HotelShareCount --;
            Debug.Log("Sell Share " +SellOne + "  " + SellTwo+"  " + SellThree + "  " +SellFour + "  " +SellFive + "  " +SellSix);
            FindObjectOfType<Scoreboard>().Updateleaderboard();
        }
    }
    public void SellFourthShare()
    {
        if(SellFour==0)
        {}
        else
        {
            ShareManager.PlayerShares[GamePlayer, SellFour] = ShareManager.PlayerShares[GamePlayer, SellFour] - 1;
            HotelData.HotelShareCounter[SellFour] = HotelData.HotelShareCounter[SellFour] + 1;
            Debug.Log("SellFour = "+SellFour+"  HotelShare = "+ HotelData.HotelShareCounter[SellFour] );
            BuyShare4.GetComponent<Image>().color = Color.white;
            BuyShare4Text.GetComponent<Text>().text = "4"; BuyShare4Text.GetComponent<Text>().color = Color.black;
            SharePrice = HotelData.ChainData[SellFour,HotelData.ChainSize[SellFour]];
            SellIndividualSharesRoutine();
            SellFour=0;
            ShareNum4 = 1;
            HotelShareCount --;
            Debug.Log("Sell Share " +SellOne + "  " + SellTwo+"  " + SellThree + "  " +SellFour + "  " +SellFive + "  " +SellSix);
            FindObjectOfType<Scoreboard>().Updateleaderboard();
        }
    }
    public void SellFifthShare()
    {
        if(SellFive==0)
        {}
        else
        {
            ShareManager.PlayerShares[GamePlayer, SellFive] = ShareManager.PlayerShares[GamePlayer, SellFive] - 1;
            HotelData.HotelShareCounter[SellFive] ++;
            BuyShare5.GetComponent<Image>().color = Color.white;
            BuyShare5Text.GetComponent<Text>().text = "5"; BuyShare5Text.GetComponent<Text>().color = Color.black;
            SharePrice = HotelData.ChainData[SellFive,HotelData.ChainSize[SellFive]];
            SellIndividualSharesRoutine();
            SellFive=0;
            ShareNum5 = 1;
            HotelShareCount --;
            Debug.Log("Sell Share " +SellOne + "  " + SellTwo+"  " + SellThree + "  " +SellFour + "  " +SellFive + "  " +SellSix);
            FindObjectOfType<Scoreboard>().Updateleaderboard();
        }
    }
    public void SellSixthShare()
    {
        if(SellSix==0)
        {}
        else
        {
            ShareManager.PlayerShares[GamePlayer, SellSix] = ShareManager.PlayerShares[GamePlayer, SellSix] - 1;
            HotelData.HotelShareCounter[SellSix] ++;
            BuyShare6.GetComponent<Image>().color = Color.white;
            BuyShare6Text.GetComponent<Text>().text = "6"; BuyShare6Text.GetComponent<Text>().color = Color.black;
            SharePrice = HotelData.ChainData[SellSix,HotelData.ChainSize[SellSix]];
            SellIndividualSharesRoutine();
            SellSix=0;
            ShareNum6 = 1;
            HotelShareCount --;
            FindObjectOfType<Scoreboard>().Updateleaderboard();
        }
    }
    
    public void BuyIndividualSharesRoutine()
    {
        SharePurchase = SharePurchase + SharePrice;
        SharePurchaseTotal.GetComponent<Text>().text = SharePurchase.ToString("$##,###");
        ShareManager.PlayerShares[GamePlayer, HotelData.HotelNum] = ShareManager.PlayerShares[GamePlayer, HotelData.HotelNum] + 1;
        ShareManager.PlayerCash[GamePlayer] = ShareManager.PlayerCash[GamePlayer] - SharePrice;
        FindObjectOfType<Scoreboard>().PlayerUpdatePanel();
    }
    public void SellIndividualSharesRoutine()
    {
        SharePurchase = SharePurchase - SharePrice;
        SharePurchaseTotal.GetComponent<Text>().text = SharePurchase.ToString("$##,###");
        ShareManager.PlayerCash[GamePlayer] = ShareManager.PlayerCash[GamePlayer] + SharePrice;
        FindObjectOfType<Scoreboard>().PlayerUpdatePanel();
    }
    

    public void OpenStartChainPanel()
    {
        //PlayerManager.GameBoardActive = false;
      
        FindObjectOfType<Scoreboard>().Updateleaderboard();;//Debug.Log("OpenStartChainPanel");
        //PlaceTilePanel.SetActive(false);//Debug.Log("Closing PlaceTilePanel");
        FindObjectOfType<TestAcquireGridVisual>().SharePurchasePanel.SetActive(false);
        FindObjectOfType<StartingHotel>().StartHotelChainPanel.SetActive(true);//Debug.Log("Opening StartHotelStartChainPanel");
 
    }
    public void OpenSharePurchasePanel()
    {
        SellOne = 0;SellTwo=0;SellThree=0;SellFour=0;SellFive=0;SellSix=0;
        if(HotelData.HotelCount == 0)
        {
            
            FindObjectOfType<TestAcquireGridVisual>().SharePurchasePanel.SetActive(false);
        }
        else
        {
            //GameBoardActive = false;
            FindObjectOfType<StartingHotel>().StartHotelChainPanel.SetActive(false);//Debug.Log("Closing StartHotelChainPanel");
            //PlaceTilePanel.SetActive(false);//Debug.Log("Closing PlaceTilePanel");
            FindObjectOfType<TestAcquireGridVisual>().SharePurchasePanel.SetActive(true);
        }
    }
    public void CloseSharePurchasePanel()
    {
        //FindObjectOfType<StartingHotel>().GameBoardActive = true;
        FindObjectOfType<StartingHotel>().StartHotelChainPanel.SetActive(false);//Debug.Log("Closing StartHotelStartChainPanel");
        //PlaceTilePanel.SetActive(true);//Debug.Log("Opening PlaceTilePanel");
        FindObjectOfType<TestAcquireGridVisual>().SharePurchasePanel.SetActive(false);

        BuyShare1.GetComponent<Image>().color = Color.white; BuyShare1Text.GetComponent<Text>().text = "1"; BuyShare1Text.GetComponent<Text>().color = Color.black;
        BuyShare2.GetComponent<Image>().color = Color.white; BuyShare2Text.GetComponent<Text>().text = "2"; BuyShare2Text.GetComponent<Text>().color = Color.black;
        BuyShare3.GetComponent<Image>().color = Color.white; BuyShare3Text.GetComponent<Text>().text = "3"; BuyShare3Text.GetComponent<Text>().color = Color.black;
        BuyShare4.GetComponent<Image>().color = Color.white; BuyShare4Text.GetComponent<Text>().text = "4"; BuyShare4Text.GetComponent<Text>().color = Color.black;
        BuyShare5.GetComponent<Image>().color = Color.white; BuyShare5Text.GetComponent<Text>().text = "5"; BuyShare5Text.GetComponent<Text>().color = Color.black;
        BuyShare6.GetComponent<Image>().color = Color.white; BuyShare6Text.GetComponent<Text>().text = "6"; BuyShare6Text.GetComponent<Text>().color = Color.black;
        //FindObjectOfType<ShareManager>().SharePurchaseTotal.GetComponent<Text>().text = 0.ToString("$##,###");
        ActionDisplay.GetComponent<Text>().text = " ";
   
        ShareNum1 = 1; ShareNum2 = 0; ShareNum3 = 0; ShareNum4 = 0; ShareNum5 = 0; ShareNum6 = 0;
        SharePurchase = 0;
        HotelShareCount = 0;
        
        //if (GamePlayer == 3)
       // {
        //    PlayerNameTurnDisplay.GetComponent<Text>().text = PlayerName[1].ToString();
        //    GamePlayer = 1;
       //     Player3Highlight.SetActive(false); 
       //     Player1Highlight.SetActive(true);
       // }
        if (GamePlayer == 1)
        {
            PlayerNameTurnDisplay.GetComponent<Text>().text = PlayerName[2].ToString();
            GamePlayer = 2;
            Player1Highlight.SetActive(false); 
            Player2Highlight.SetActive(true);
        }
        else if (GamePlayer == 2)
        {
            PlayerNameTurnDisplay.GetComponent<Text>().text = PlayerName[1].ToString();
            GamePlayer = 1;
            Player2Highlight.SetActive(false); 
            Player3Highlight.SetActive(true); 
        }
        //PlaceTilePanel.SetActive(true);   
   }
}
