using Fusion;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameStarter : MonoBehaviour
{
    public enum Mode
    {
        Pregame,
        Lobby
    }

    private class SessionWrapper : GameStarterUI.IRoomInfo
    {
        public SessionInfo SessionInfo { get; set; }

        public string Id => SessionInfo.Name;

        public string Name => (string)SessionInfo.Properties["name"].PropertyValue;

        public int CurPlayer => SessionInfo.PlayerCount;

        public int MaxPlayer => SessionInfo.MaxPlayers;
    }

    public static string desireNickname;

    [SerializeField] private Mode mode;
    [SerializeField] private NetworkRunner lobbyRunner;
    [SerializeField] private NetworkGameLobby gameLobby;
    [SerializeField] private GameStarterUI gameStarterUI;
    private int updateRef;
    private List<SessionInfo> sessions = new List<SessionInfo>();

    public System.Action<bool> OnJoinLobbyResult;

    private System.Action mainThreadJoinLobbyCallback;

    private void Start()
    {
        gameStarterUI.Show(GameStarterUI.Mode.Pregame);
        gameStarterUI.OnCreateRoomClick = OnCreateRoom;
        gameStarterUI.OnJoinLobbyClick = OnJoinLobby;
        gameStarterUI.OnJoinRoomClick = OnJoinRoom;
    }

    private void OnJoinLobby(string userNickname)
    {
        desireNickname = userNickname;

        lobbyRunner.JoinSessionLobby(SessionLobby.ClientServer).ContinueWith(t =>
        {
            bool joinLobbySuccess = t.Result.Ok;
            mainThreadJoinLobbyCallback = () =>
            {
                OnJoinLobbyResult?.Invoke(joinLobbySuccess);
            };
        });
    }

    private void OnCreateRoom(string roomName)
    {
        Debug.Log("Set player count here");
        gameLobby.CreateRoom(roomName, 6);
    }

    private void OnJoinRoom(string roomId)
    {
        gameLobby.JoinRoom(roomId);
    }

    private void Update()
    {
        Mode curMode = Mode.Pregame;


        if(lobbyRunner.LobbyInfo.IsValid)
        {
            curMode = Mode.Lobby;
        }

        if(curMode != mode)
        {
            mode = curMode;
            gameStarterUI.Show(mode == Mode.Pregame ? GameStarterUI.Mode.Pregame : GameStarterUI.Mode.Lobby);
        }

        switch(mode)
        {
            case Mode.Pregame:

                break;
            case Mode.Lobby:
                {
                    if(!gameLobby.HasNewUpdate(ref updateRef))
                    {
                        return;
                    }
                    sessions.Clear();
                    gameLobby.GetSessions(sessions);

                    List<SessionWrapper> wrappers = new List<SessionWrapper>();
                    foreach(var session in sessions)
                    {
                        wrappers.Add(new SessionWrapper
                        {
                            SessionInfo = session,
                        });
                    }

                    gameStarterUI.DisplayRoomList(wrappers);
                }
                break;
        }
    }
}
