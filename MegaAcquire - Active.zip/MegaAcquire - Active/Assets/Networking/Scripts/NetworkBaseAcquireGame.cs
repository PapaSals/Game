using Fusion;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;

public interface IBaseAcquireHandler
{    
    public void HandleVisualStartGame();
    public void HandleVisualNextTurn(bool isMyTurn);
    public void HandleVisualNextMergeTurn(bool isMergeTurnEnabled, bool isMyMergeTurn);
    public void HandleLogicStartGame();
    public bool HandleLogicMerge(byte playerId, ushort tileId, byte mergeSelection);
    public bool HandleLogicCreateChain(byte playerId, ushort tileId, byte chainId);
    public bool HandleLogicPlace(byte playerId, ushort tileId);
    public int[] SortPlayerToBeginMerge(ushort tileId, byte mergeSelection);
    bool HandleLogicPurchaseShare(byte playerId, byte[] hotelIds, byte[] amounts);
    bool HandleLogicSellShare(byte playerId, byte hotelId, byte amount);
    bool HandleLogicExchangeShare(byte playerId, byte hotelId, byte amount);
}

public class NetworkBaseAcquireGame : NetworkBehaviour
{
    [SerializeField] private NetworkAcquireGameConfiguration config;
    
    [Networked] public NetworkRoom Room { get; set; }
    [Networked] public int PlayerCount { get; private set; }
    [Networked] public int RandomSeed { get; private set; }
    [Networked, Capacity(8)] public NetworkArray<PlayerRef> Players { get; }
    //[OnChangedRender(nameof(OnTurnChange))]
    [Networked] public int CurrentTurn { get; set; }
    [Networked] public TickTimer TimerTillNextTurn { get; set; }
    [Networked] public TickTimer TimerTillGameStart { get; set; }
    //[OnChangedRender(nameof(OnMergeTurnChange))]
    [Networked] public int MergeTurn { get; set; }
    [Networked,Capacity(8)] public NetworkArray<PlayerRef> MergePlayers { get; }
    [Networked] public NetworkBool IsInMergeTurn { get; set; }

    public IBaseAcquireHandler Handler { get; set; }
    private ChangeDetector onChangeRender;

    public T GetHandler<T>() where T : IBaseAcquireHandler
    {
        if (Handler is T t)
            return t;
        return default;
    }

    protected bool TryGetHandler<T>(out T t)
    {
        if (Handler == null)
        {
            t = default;
            return false;
        }
        if(Handler is T h)
        {
            t = h;
            return true;
        }
        t = default;
        return false;
    }

    public void Initialize(NetworkRoom room)
    {
        Room = room;
        PlayerCount = room.PlayerToStartGame;

        List<PlayerRef> originList = new List<PlayerRef>();
        List<PlayerRef> randomList = new List<PlayerRef>();
        foreach(var kv in room.Players)
        {
            originList.Add(kv.Key);
        }        
        while(originList.Count > 0)
        {
            var rd = UnityEngine.Random.Range(0, originList.Count);
            var pf = originList[rd];
            randomList.Add(pf);
            originList.RemoveAt(rd);
        }

        Players.CopyFrom(randomList, 0, randomList.Count);
        RandomSeed = UnityEngine.Random.Range(0, 1_000_000_000);
    }

    public override void Spawned()
    {
        onChangeRender = GetChangeDetector(ChangeDetector.Source.SimulationState);
        if (HasStateAuthority)
        {
            TimerTillGameStart = TickTimer.CreateFromSeconds(Runner, config.timeTillStart);
            CurrentTurn = -1;
        }
        Handler.HandleLogicStartGame();
    }

    [Rpc(RpcSources.All, RpcTargets.All, HostMode = RpcHostMode.SourceIsHostPlayer)]
    public void RpcOpenTile(ushort tileId, RpcInfo info = default)
    {
        if (!IsThisPlayerTurn(info.Source))
            return;

        byte playerId = GetPlayerId(info.Source); 
        if (!Handler.HandleLogicPlace(playerId, tileId))
            Debug.LogError("Error, can't handle logic place!");
    }

    [Rpc(RpcSources.All, RpcTargets.All, HostMode = RpcHostMode.SourceIsHostPlayer)]
    public void RpcOpenTileWithMerge(ushort tileId, byte mergeSelection, RpcInfo info = default)
    {
        if (!IsThisPlayerTurn(info.Source))
            return;

        byte playerId = GetPlayerId(info.Source);

        if (Handler.HandleLogicMerge(playerId, tileId, mergeSelection))
        {
            IsInMergeTurn = true;
            MergeTurn = -1;

            int[] players = Handler.SortPlayerToBeginMerge(tileId, mergeSelection);

            for (int i = 0; i < PlayerCount; i++)
            {
                MergePlayers.Set(i, Players[players[i]]);
            }

            TimerTillNextTurn = TickTimer.CreateFromSeconds(Runner, config.timeTillNextTurn);
        }
        else
        {
            Debug.LogError("Error, can't handle logic merge!");
        }
    }

    [Rpc(RpcSources.All, RpcTargets.All, HostMode = RpcHostMode.SourceIsHostPlayer)]
    public void RpcOpenTileWithCreateChain(ushort tileId, byte chainId, RpcInfo info = default)
    {
        if (!IsThisPlayerTurn(info.Source))
            return;

        byte playerId = GetPlayerId(info.Source);
        if (!Handler.HandleLogicCreateChain(playerId, tileId, chainId))
            Debug.LogError("Error, can't handle create chain!");
    }

    [Rpc(RpcSources.All, RpcTargets.All,HostMode = RpcHostMode.SourceIsHostPlayer)]
    public void RpcEndMyTurn(RpcInfo info = default)
    {
        if (!IsThisPlayerTurn(info.Source))
            return;

        if(IsInMergeTurn)
        {
            Debug.Log("Is In Merge turn, can't end this turn now");
            return;
        }

        TimerTillNextTurn = TickTimer.CreateFromSeconds(Runner, config.timeTillNextTurn);
    }

    [Rpc(RpcSources.All, RpcTargets.All, HostMode = RpcHostMode.SourceIsHostPlayer)]
    public void RpcEndMyMergeTurn(RpcInfo info = default)
    {
        if(!IsInMergeTurn)
        {
            Debug.Log("Not in merge turn");
            return;
        }

        if(!IsThisPlayerMergeTurn(info.Source))
        {
            return;
        }

        Debug.Log($"Player {info.Source} ends his merge turn!");
        //MergeTurn++;
        TimerTillNextTurn = TickTimer.CreateFromSeconds(Runner, config.timeTillNextTurn);

        //MergeTurn++;
        //if(MergeTurn >= PlayerCount)
        //{
        //    TimerTillNextTurn = TickTimer.CreateFromSeconds(Runner, config.timeTillNextTurn);
        //}
    }
    [Rpc(RpcSources.All, RpcTargets.All, HostMode = RpcHostMode.SourceIsHostPlayer)]
    public void RpcPurchaseShare(byte[] hotelIds, byte[] amounts, RpcInfo info = default)
    {
        if (IsInMergeTurn)
            return;

        if (!IsThisPlayerTurn(info.Source))
            return;

        byte playerId = GetPlayerId(info.Source);

        if (!Handler.HandleLogicPurchaseShare(playerId, hotelIds, amounts))
        {
            Debug.Log("Can't purchase such amounts");
            return;
        }
        Debug.Log("Purchase amount success!");
    }

    [Rpc(RpcSources.All, RpcTargets.All, HostMode = RpcHostMode.SourceIsHostPlayer)]
    public void RpcSellShareInMergeTurn(byte hotelId, byte amount, RpcInfo info = default)
    {
        if (!IsInMergeTurn)
            return;

        if (!IsThisPlayerMergeTurn(info.Source))
            return;

        byte playerId = GetPlayerId(info.Source);

        if (!Handler.HandleLogicSellShare(playerId, hotelId, amount))
        {
            Debug.LogError("Can't sell share!");
            return;
        }
        Debug.Log("Sell share completed!");
    }

    [Rpc(RpcSources.All, RpcTargets.All, HostMode = RpcHostMode.SourceIsHostPlayer)]
    public void RpcExchangeShareInMergeTurn(byte hotelId, byte amount, RpcInfo info = default)
    {
        if (!IsInMergeTurn)
            return;

        if (!IsThisPlayerMergeTurn(info.Source))
            return;

        byte playerId = GetPlayerId(info.Source);


        if (!Handler.HandleLogicExchangeShare(playerId, hotelId, amount))
        {
            Debug.LogError("Can't exchange share!");
            return;
        }

        Debug.Log("Exchange share completed!");
    }

    protected byte GetPlayerId(PlayerRef pref)
    {
        for (int i = 0; i < PlayerCount; i++)
        {
            var p = Players[i];
            if(p == pref)
            {
                return (byte)i;
            }
        }
        return 0;
    }

    protected bool IsThisPlayerTurn(PlayerRef pref)
    {
        if (CurrentTurn < 0)
            return false;

        int curPlayerTurn = (CurrentTurn % PlayerCount);
        return pref == Players[curPlayerTurn];
    }

    protected bool IsThisPlayerMergeTurn(PlayerRef pref)
    {
        if (MergeTurn < 0)
            return false;
        if (MergeTurn >= PlayerCount)
            return false;
        return pref == MergePlayers[MergeTurn];
    }

    public byte GetMyPlayerId()
    {
        var mine = Runner.LocalPlayer;

        for (int i = 0; i < PlayerCount; i++)
        {
            var r = Players[i];
            if(r == mine)
            {
                return (byte)i;
            }
        }
        return byte.MaxValue;
    }

    public bool IsMyTurn() => IsThisPlayerTurn(Runner.LocalPlayer);
    public bool IsMyMergeTurn() => IsThisPlayerMergeTurn(Runner.LocalPlayer);

    public override void FixedUpdateNetwork()
    {
        if(TimerTillGameStart.Expired(Runner))
        {
            CurrentTurn = 0;
            TimerTillGameStart = TickTimer.None;
        }

        if(TimerTillNextTurn.Expired(Runner))
        {
            if(IsInMergeTurn)
            {
                MergeTurn++;
                if(MergeTurn >= PlayerCount)
                {
                    MergeTurn = 0;
                    IsInMergeTurn = false;
                }
                TimerTillNextTurn = TickTimer.None;
            }
            else
            {
                CurrentTurn++;
                TimerTillNextTurn = TickTimer.None;
            }
        }
    }

    public override void Render()
    {
        foreach(var change in onChangeRender.DetectChanges(this))
        {
            switch(change)
            {
                case nameof(CurrentTurn):
                    OnTurnChange();
                    break;
                case nameof(MergeTurn):
                    OnMergeTurnChange();
                    break;
            }
        }
    }

    private void OnTurnChange()
    {
        if (CurrentTurn == 0)
        {
            Handler.HandleVisualStartGame();
        }
        Handler.HandleVisualNextTurn(IsThisPlayerTurn(Runner.LocalPlayer));
    }

    private void OnMergeTurnChange()
    {
        if (!IsInMergeTurn)
            Handler.HandleVisualNextMergeTurn(false, false);
        else
            Handler.HandleVisualNextMergeTurn(true, IsThisPlayerMergeTurn(Runner.LocalPlayer));
    }   
}