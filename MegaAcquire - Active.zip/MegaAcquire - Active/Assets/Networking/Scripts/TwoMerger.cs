using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System;


public class TwoMerger : MonoBehaviour
{
    public static string ChainOne;public static int ChainOneSize;
    public static string ChainTwo;public static int ChainTwoSize;
    public static string ChainTemp;public static int ChainTempSize;
    public GameObject FirstChain;public GameObject SecondChain;
    
    public GameObject FirstPlayer;public GameObject SecondPlayer;public GameObject ThirdPlayer;
    public GameObject FourthPlayer;public GameObject FifthPlayer;public GameObject SixthPlayer;
    public GameObject MFirstShare;public GameObject MSecondShare;public GameObject MThirdShare;
    public GameObject MFourthShare;public GameObject MFifthShare;public GameObject MSixthShare;
    public int FirstShare;public int SecondShare;public int ThirdShare;
    public int FourthShare;public int FifthShare;public int SixthShare;
    public GameObject FirstBonus;public GameObject SecondBonus;public GameObject ThirdBonus;
    public GameObject FourthBonus;public GameObject FifthBonus;public GameObject SixthBonus;
    public GameObject TwoMergerPanel;public GameObject TwoTiedMergerPanel;
    public static int MergerChainNumber;

    public static int MajorityBonus;
    public static int P1MajorityBonus;
    public static int P2MajorityBonus;
    public static int P3MajorityBonus;
    public static int P4MajorityBonus;
    public static int P5MajorityBonus;
    public static int P6MajorityBonus;

    public static int takeoverhotel;

     
    public int ShareNum1 = 1;public int ShareNum2 = 0;public int ShareNum3 = 0;public int ShareNum4 = 0;public int ShareNum5 = 0;public int ShareNum6 = 0;
    public GameObject LuxorShareButton;public GameObject GlobalShareButton;public GameObject ArcadiaShareButton;public GameObject RegalShareButton;

    public GameObject LuxorChain;public GameObject GlobalChain;public GameObject ArcadiaChain;public GameObject RegalChain;
    

    public GameObject mergeThreePanel;

    public GameObject FoundersShareLusterRoutine;
    public GameObject mergingTile;
  
    public GameObject LuxorHotel; public List<GameObject> LuxorTiles; public bool LuxorAvailable = true;
    public GameObject GlobalHotel; public List<GameObject> GlobalTiles; public bool betaAvailable = true;
    public GameObject ArcadiaHotel; public List<GameObject> ArcadiaTiles; public bool ArcadiaAvailable = true;
    public GameObject RegalHotel;public List<GameObject> RegalTiles; public bool charlieAvailable = true;

   

    public GameObject mergeTile;

    public int GamePlayer = 1;

    public GameObject takeoverChain; 
    public GameObject victimChain;

    // Update is called once per frame
    public void StartTwoMerger()
    {
        //FindFirstObjectByType<ShareManager>().PlaceTilePanel.SetActive(false);
        FindObjectOfType<TestAcquireGridVisual>().SharePurchasePanel.SetActive(false);
        TwoMergerPanel.SetActive(true);
        
    }
    public void twochainmergerroutine()
    {
        if(ChainOne == "LuxorHotel") { ChainOneSize = HotelData.ChainSize[1];}
        if(ChainTwo == "LuxorHotel") { ChainTwoSize = HotelData.ChainSize[1];}
        if(ChainOne == "GlobalHotel") { ChainOneSize = HotelData.ChainSize[5];}
        if(ChainTwo == "GlobalHotel") { ChainTwoSize = HotelData.ChainSize[5];}
        if(ChainOne == "ArcadiaHotel") { ChainOneSize = HotelData.ChainSize[7];}
        if(ChainTwo == "ArcadiaHotel") { ChainTwoSize = HotelData.ChainSize[7];}
        if(ChainOne == "RegalHotel") { ChainOneSize = HotelData.ChainSize[11];}
        if(ChainTwo == "RegalHotel") { ChainTwoSize = HotelData.ChainSize[11];}
        print("PM436   ChainOne "+ChainOne+"  "+ChainOneSize+ "  ChainTwo "+ChainTwo+"  "+ChainTwoSize);
        
        if(ChainOneSize > ChainTwoSize)
        {
        }
        else
        {
            int temp = 0; string tempname="";
            tempname = ChainOne;
            ChainOne = ChainTwo;
            ChainTwo = tempname;
            temp = ChainOneSize;
            ChainOneSize = ChainTwoSize;
            ChainTwoSize = temp;
        }

        if(ChainOne == "LuxorHotel") { ChainOneSize = HotelData.ChainSize[1];takeoverhotel=1;}
        if(ChainTwo == "LuxorHotel") { ChainTwoSize = HotelData.ChainSize[1];}
        if(ChainOne == "GlobalHotel") { ChainOneSize = HotelData.ChainSize[5];takeoverhotel=5;}
        if(ChainTwo == "GlobalHotel") { ChainTwoSize = HotelData.ChainSize[5];}
        if(ChainOne == "ArcadiaHotel") { ChainOneSize = HotelData.ChainSize[7];takeoverhotel=7;}
        if(ChainTwo == "ArcadiaHotel") { ChainTwoSize = HotelData.ChainSize[7];}
        if(ChainOne == "RegalHotel") { ChainOneSize = HotelData.ChainSize[11];takeoverhotel=11;}
        if(ChainTwo == "RegalHotel") { ChainTwoSize = HotelData.ChainSize[11];}
                    
        print("PM469   ChainOne "+ChainOne+"  "+ChainOneSize+ "  ChainTwo "+ChainTwo+"  "+ChainTwoSize);
    
        print("PM471 Take over Hotel is :" + takeoverhotel);

        if (ChainOne == "LuxorHotel") 
        { 
            ChainOneSize = HotelData.ChainSize[1];
            FirstChain.SetActive(true);
            Color newColor = new Color(230/ 255f, 230 / 255f, 105 / 255f);
            FirstChain.GetComponent<Button>().image.color = newColor;
            FirstChain.GetComponentInChildren<Text>().text = "Luxor";
        }
        else if (ChainTwo == "LuxorHotel")
        {
            ChainTwoSize = HotelData.ChainSize[1];
            SecondChain.SetActive(true);
            Color newColor = new Color(230/ 255f, 230 / 255f, 105 / 255f);
            SecondChain.GetComponent<Button>().image.color = newColor;
            SecondChain.GetComponentInChildren<Text>().text = "Luxor";
        }
        if (ChainOne == "GlobalHotel") 
        { 
            ChainOneSize = HotelData.ChainSize[5];
            FirstChain.SetActive(true);
            Color newColor = new Color(240/ 255f, 135 / 255f, 20 / 255f);
            FirstChain.GetComponent<Button>().image.color = newColor;
            FirstChain.GetComponentInChildren<Text>().text = "Global";
        }
        else if (ChainTwo == "GlobalHotel")
        {
            ChainTwoSize = HotelData.ChainSize[5];
            SecondChain.SetActive(true);
            Color newColor = new Color(240/ 255f, 135 / 255f, 20 / 255f);
            SecondChain.GetComponent<Button>().image.color = newColor;
            SecondChain.GetComponentInChildren<Text>().text = "Global";
        }
        if (ChainOne == "ArcadiaHotel") 
        { 
            ChainOneSize = HotelData.ChainSize[7];
            FirstChain.SetActive(true);
            Color newColor = new Color(125/ 255f, 130 / 255f, 225 / 255f);
            FirstChain.GetComponent<Button>().image.color = newColor;
            FirstChain.GetComponentInChildren<Text>().text = "Arcadia";
        }
        else if (ChainTwo == "ArcadiaHotel")
        {
            ChainTwoSize = HotelData.ChainSize[7];
            SecondChain.SetActive(true);
            Color newColor = new Color(125/ 255f, 130 / 255f, 225 / 255f);
            SecondChain.GetComponent<Button>().image.color = newColor;
            SecondChain.GetComponentInChildren<Text>().text = "Arcadia";
        }
        if (ChainOne == "RegalHotel") 
        { 
            ChainOneSize = HotelData.ChainSize[11];
            FirstChain.SetActive(true);
            Color Regal = new Color(80/ 255f, 40 / 255f, 160 / 255f);
            FirstChain.GetComponent<Button>().image.color = Regal;
            FirstChain.GetComponentInChildren<Text>().text = "Regal";
        }
        else if (ChainTwo == "RegalHotel")
        {
            ChainTwoSize = HotelData.ChainSize[11];
            SecondChain.SetActive(true);
            Color Regal = new Color(80/ 255f, 40 / 255f, 160 / 255f);
            SecondChain.GetComponent<Button>().image.color = Regal;
            SecondChain.GetComponentInChildren<Text>().text = "Regal";
        }
        print("PM537   ChainOne "+ChainOne+"  "+ChainOneSize+ "  ChainTwo "+ChainTwo+"  "+ChainTwoSize);
    }
public void MergeTwo(GameObject takeoverChain)  
    {
        FindObjectOfType<TestAcquireGridVisual>().SharePurchasePanel.SetActive(false);
    
        
        if(takeoverChain.name == "LuxorChain")
        {
            //print("Luxor Takes over " + PlayerManager.ChainTwo);
            takeoverhotel=1;
          
            //if(ChainTwo  == "LuxorHotel"){RemoveLuxor();}
            //if(ChainTwo  == "GlobalHotel"){RemoveGlobal();}
            //if(ChainTwo  == "ArcadiaHotel"){RemoveArcadia();}
            //if(ChainTwo  == "RegalHotel"){RemoveRegal();}
            //AddToLuxor(mergingTile);
         
        }
        else if (takeoverChain.name == "GlobalChain")
        {
            //print("Global Takes over " + PlayerManager.ChainTwo);
            takeoverhotel=5;
        
            //if(ChainTwo  == "LuxorHotel"){RemoveLuxor();}
            //if(ChainTwo  == "GlobalHotel"){RemoveGlobal();}
            //if(ChainTwo  == "ArcadiaHotel"){RemoveArcadia();}
            //if(ChainTwo  == "RegalHotel"){RemoveRegal();}
            //AddToGlobal(mergingTile);
          
        }
        else if (takeoverChain.name == "ArcadiaChain")
        {
            //print("Arcadia Takes over " + PlayerManager.ChainTwo);
            takeoverhotel=7;
      
            //if(ChainTwo  == "LuxorHotel"){RemoveLuxor();}
            //if(ChainTwo  == "GlobalHotel"){RemoveGlobal();}
            //if(ChainTwo  == "ArcadiaHotel"){RemoveArcadia();}
            //if(ChainTwo  == "RegalHotel"){RemoveRegal();}
            //AddToArcadia(mergingTile);
         
        }
        else if (takeoverChain.name == "RegalChain")
        {
            //print("Regal Takes over " + PlayerManager.ChainTwo);
            takeoverhotel=11;
      
            //if(ChainTwo  == "LuxorHotel"){RemoveLuxor();}
            //if(ChainTwo  == "GlobalHotel"){RemoveGlobal();}
            //if(ChainTwo  == "ArcadiaHotel"){RemoveArcadia();}
            //if(ChainTwo  == "RegalHotel"){RemoveRegal();}
            //AddToRegal(mergingTile);
       
        }
        
        HotelData.HotelCount --;   //reducing number of hotel chains by one
        //FindFirstObjectByType<ShareManager>().PlaceTilePanel.SetActive(false);
         
        mergingTile = null;
    }
    public void majoritybonuscalculations()
    {
        //FindFirstObjectByType<ShareManager>().PlaceTilePanel.SetActive(false);
      FindObjectOfType<TestAcquireGridVisual>().SharePurchasePanel.SetActive(false);
        FindFirstObjectByType<MajorityBonus>().MergerDistributionPanel.SetActive(true);
        TwoMergerPanel.SetActive(false);
    
        if(ChainTwo == "LuxorHotel"){MergerChainNumber = 1;}
        if(ChainTwo == "GlobalHotel"){MergerChainNumber = 5;}
        if(ChainTwo == "ArcadiaHotel"){MergerChainNumber = 7;}
        if(ChainTwo == "RegalHotel"){MergerChainNumber = 11;}

        MajorityBonus = 10*HotelData.ChainData[MergerChainNumber,ChainTwoSize];

        Debug.Log("calculating majority Bonus");
        Debug.Log("Takeover Hotel number is: "+ MergerChainNumber);
        Debug.Log("Takeover Hotel Size is: "+ ChainTwoSize);
        Debug.Log("Majority Bonus is: "+ MajorityBonus);

        UpdatePlayerMerger();
        UpdateMergerPanel();
        FindFirstObjectByType<MajorityBonus>().CalculateShares();

        //GameBoardActive = true;

    }

   public void UpdatePlayerMerger()
    {
        //HotelData.PlayerShares[4,1] = 1;HotelData.PlayerShares[4,5] = 0; HotelData.PlayerShares[4,7] = 0;HotelData.PlayerShares[4,11]=1;
        //HotelData.PlayerShares[5,1] = 1;HotelData.PlayerShares[5,5] = 0; HotelData.PlayerShares[5,7] = 2;HotelData.PlayerShares[5,11]=0; 
        //HotelData.PlayerShares[6,1] = 1;HotelData.PlayerShares[6,5] = 1; HotelData.PlayerShares[6,7] = 0;HotelData.PlayerShares[6,11]=1; 
        
        
        FirstShare = ShareManager.PlayerShares[1,MergerChainNumber];
        SecondShare = ShareManager.PlayerShares[2,MergerChainNumber];
        ThirdShare = ShareManager.PlayerShares[3,MergerChainNumber];
        FourthShare = ShareManager.PlayerShares[4,MergerChainNumber];
        FifthShare = ShareManager.PlayerShares[5,MergerChainNumber];
        SixthShare = ShareManager.PlayerShares[6,MergerChainNumber];
      
    }

    public void UpdateMergerPanel()
    {
        MFirstShare.GetComponentInChildren<Text>().text = FirstShare.ToString();
        MSecondShare.GetComponentInChildren<Text>().text = SecondShare.ToString();
        MThirdShare.GetComponentInChildren<Text>().text = ThirdShare.ToString();
        MFourthShare.GetComponentInChildren<Text>().text = FourthShare.ToString();
        MFifthShare.GetComponentInChildren<Text>().text = FifthShare.ToString();
        MSixthShare.GetComponentInChildren<Text>().text = SixthShare.ToString();

        //HotelData.PlayerShares[1, 5].ToString();

        FirstBonus.GetComponentInChildren<Text>().text = P1MajorityBonus.ToString("$##,###");
        SecondBonus.GetComponentInChildren<Text>().text = P2MajorityBonus.ToString("$##,###");
        ThirdBonus.GetComponentInChildren<Text>().text = P3MajorityBonus.ToString("$##,###");
        FourthBonus.GetComponentInChildren<Text>().text = P4MajorityBonus.ToString("$##,###");
        FifthBonus.GetComponentInChildren<Text>().text = P5MajorityBonus.ToString("$##,###");
        SixthBonus.GetComponentInChildren<Text>().text = P6MajorityBonus.ToString("$##,###"); 

        FirstPlayer.GetComponentInChildren<Text>().text = ShareManager.PlayerName[1];
        SecondPlayer.GetComponentInChildren<Text>().text = ShareManager.PlayerName[2];
        ThirdPlayer.GetComponentInChildren<Text>().text = ShareManager.PlayerName[3];
        FourthPlayer.GetComponentInChildren<Text>().text = ShareManager.PlayerName[4];
        FifthPlayer.GetComponentInChildren<Text>().text = ShareManager.PlayerName[5];
        SixthPlayer.GetComponentInChildren<Text>().text = ShareManager.PlayerName[6];
    
    }
    
}

    