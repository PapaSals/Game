using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Acquire/New Network Acquire Game Configuration")]
public class NetworkAcquireGameConfiguration : ScriptableObject
{    
    public float timeTillNextTurn = 1f;
    public float timeTillStart = 2f;
}
