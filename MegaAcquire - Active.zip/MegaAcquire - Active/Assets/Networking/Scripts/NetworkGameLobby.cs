using Fusion;
using Fusion.Sockets;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NetworkGameLobby : MonoBehaviour, INetworkRunnerCallbacks
{
    [SerializeField] private NetworkRunner gameRunner;

    private List<SessionInfo> sessionInfos = new List<SessionInfo>();

    private int updateMask = 0;

    public void OnSessionListUpdated(NetworkRunner runner, List<SessionInfo> sessionList)
    {
        sessionInfos.Clear();
        sessionInfos.AddRange(sessionList);
        updateMask++;
    }

    public bool HasNewUpdate(ref int mask)
    {
        if(mask == updateMask)
        {
            return false;
        }

        mask = updateMask;
        return true;
    }

    public void GetSessions(List<SessionInfo> sessions)
    {
        sessions.AddRange(sessionInfos);
    }

    public void CreateRoom(string roomName, int maxPlayer)
    {
        var runner = Instantiate(gameRunner);

        var args = new StartGameArgs();

        string name = !string.IsNullOrEmpty(roomName) ? roomName : $"Room {UnityEngine.Random.Range(1000, 9999)}";

        Dictionary<string, SessionProperty> properties = new Dictionary<string, SessionProperty>
        {
            { "name",  name}
        };
        args.GameMode = GameMode.Host;
        args.PlayerCount = maxPlayer;
        args.Scene = SceneRef.FromIndex(1);

        args.SessionProperties = properties;
        if(!string.IsNullOrEmpty(GameStarter.desireNickname))
            args.ConnectionToken = System.Text.Encoding.UTF8.GetBytes(GameStarter.desireNickname);

        runner.StartGame(args);
    }

    public void JoinRoom(string id)
    {
        var runner = Instantiate(gameRunner);

        var args = new StartGameArgs();

        args.SessionName = id; 
        args.Scene = SceneRef.FromIndex(1);
        args.GameMode = GameMode.Client;
        if (!string.IsNullOrEmpty(GameStarter.desireNickname))
            args.ConnectionToken = System.Text.Encoding.UTF8.GetBytes(GameStarter.desireNickname);
        runner.StartGame(args);
    }

    #region unused
    public void OnConnectedToServer(NetworkRunner runner)
    {
        
    }

    public void OnConnectFailed(NetworkRunner runner, NetAddress remoteAddress, NetConnectFailedReason reason)
    {
        
    }

    public void OnConnectRequest(NetworkRunner runner, NetworkRunnerCallbackArgs.ConnectRequest request, byte[] token)
    {
        
    }

    public void OnCustomAuthenticationResponse(NetworkRunner runner, Dictionary<string, object> data)
    {
        
    }

    public void OnDisconnectedFromServer(NetworkRunner runner, NetDisconnectReason reason)
    {
        
    }

    public void OnHostMigration(NetworkRunner runner, HostMigrationToken hostMigrationToken)
    {
        
    }

    public void OnInput(NetworkRunner runner, NetworkInput input)
    {
        
    }

    public void OnInputMissing(NetworkRunner runner, PlayerRef player, NetworkInput input)
    {
        
    }

    public void OnObjectEnterAOI(NetworkRunner runner, NetworkObject obj, PlayerRef player)
    {
        
    }

    public void OnObjectExitAOI(NetworkRunner runner, NetworkObject obj, PlayerRef player)
    {
        
    }

    public void OnPlayerJoined(NetworkRunner runner, PlayerRef player)
    {
        
    }

    public void OnPlayerLeft(NetworkRunner runner, PlayerRef player)
    {
        
    }

    public void OnReliableDataProgress(NetworkRunner runner, PlayerRef player, ReliableKey key, float progress)
    {
        
    }

    public void OnReliableDataReceived(NetworkRunner runner, PlayerRef player, ReliableKey key, ArraySegment<byte> data)
    {
        
    }

    public void OnSceneLoadDone(NetworkRunner runner)
    {
        
    }

    public void OnSceneLoadStart(NetworkRunner runner)
    {
        
    }

    

    public void OnShutdown(NetworkRunner runner, ShutdownReason shutdownReason)
    {
        
    }

    public void OnUserSimulationMessage(NetworkRunner runner, SimulationMessagePtr message)
    {
        
    }
    #endregion
}
