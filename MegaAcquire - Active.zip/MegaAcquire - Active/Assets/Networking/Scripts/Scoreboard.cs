using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Scoreboard : MonoBehaviour
{
    public GameObject ScoreBoardPanel;
    
    [Header("Scoreboard")]
     public GameObject PlayerNameTurnDisplay; 
    public GameObject LuxorShareBalanceDisplay;public GameObject LuxorShareValueDisplay;public GameObject LuxorChainSizeDisplay;
    public GameObject GlobalShareBalanceDisplay;public GameObject GlobalShareValueDisplay;public GameObject GlobalChainSizeDisplay;
    public GameObject ArcadiaShareBalanceDisplay;public GameObject ArcadiaShareValueDisplay;public GameObject ArcadiaChainSizeDisplay;
    public GameObject RegalShareBalanceDisplay;public GameObject RegalShareValueDisplay;public GameObject RegalChainSizeDisplay;
   
    public GameObject Player1ValueDisplay;public GameObject Player2ValueDisplay;public GameObject Player3ValueDisplay;
    public GameObject Player1CashDisplay;public GameObject Player1LuxorSharesDisplay;public GameObject Player1GlobalSharesDisplay;public GameObject Player1ArcadiaSharesDisplay;public GameObject Player1RegalSharesDisplay;
    public GameObject Player2CashDisplay;public GameObject Player2LuxorSharesDisplay;public GameObject Player2GlobalSharesDisplay;public GameObject Player2ArcadiaSharesDisplay;public GameObject Player2RegalSharesDisplay;
    public GameObject Player3CashDisplay;public GameObject Player3LuxorSharesDisplay;public GameObject Player3GlobalSharesDisplay;public GameObject Player3RegalSharesDisplay;public GameObject Player3ArcadiaSharesDisplay;
    public GameObject Player1Highlight;public GameObject Player2Highlight;public GameObject Player3Highlight;
    public GameObject Player1Display; public GameObject Player2Display;public GameObject Player3Display;

    
    
    void Start()
    {
        ScoreBoardPanel.SetActive(true);
        Player1Display.GetComponent<Text>().text = "Adam".ToString();
        Player2Display.GetComponent<Text>().text = "Matthew".ToString();
        Player3Display.GetComponent<Text>().text = "Ben".ToString();

   
    
        //PlayerNameTurnDisplay.GetComponent<Text>().text = ShareManager.PlayerName[1].ToString();
        Player1Highlight.SetActive(true); 
    }

  public void Updateleaderboard()
    {
        //FindFirstObjectByType<Endgame>().CalculatePlayerValue();
        
        Player1ValueDisplay.GetComponent<Text>().text = ShareManager.PlayerValue[1].ToString("###,###");
        Player1CashDisplay.GetComponent<Text>().text = ShareManager.PlayerCash[1].ToString("###,###");
        Player1LuxorSharesDisplay.GetComponent<Text>().text = ShareManager.PlayerShares[1, 1].ToString();
        Player1GlobalSharesDisplay.GetComponent<Text>().text = ShareManager.PlayerShares[1, 5].ToString();
        Player1ArcadiaSharesDisplay.GetComponent<Text>().text = ShareManager.PlayerShares[1, 7].ToString();
        Player1RegalSharesDisplay.GetComponent<Text>().text = ShareManager.PlayerShares[1, 11].ToString();
        
        Player2ValueDisplay.GetComponent<Text>().text = ShareManager.PlayerValue[2].ToString("###,###");
        Player2CashDisplay.GetComponent<Text>().text = ShareManager.PlayerCash[2].ToString("###,###");
        Player2LuxorSharesDisplay.GetComponent<Text>().text = ShareManager.PlayerShares[2, 1].ToString();
        Player2GlobalSharesDisplay.GetComponent<Text>().text = ShareManager.PlayerShares[2, 5].ToString();
        Player2ArcadiaSharesDisplay.GetComponent<Text>().text = ShareManager.PlayerShares[2, 7].ToString();
        Player2RegalSharesDisplay.GetComponent<Text>().text = ShareManager.PlayerShares[2, 11].ToString();

        Player3ValueDisplay.GetComponent<Text>().text = ShareManager.PlayerValue[3].ToString("###,###");
        Player3CashDisplay.GetComponent<Text>().text = ShareManager.PlayerCash[3].ToString("###,###");
        Player3LuxorSharesDisplay.GetComponent<Text>().text = ShareManager.PlayerShares[3, 1].ToString();
        Player3GlobalSharesDisplay.GetComponent<Text>().text = ShareManager.PlayerShares[3, 5].ToString();
        Player3ArcadiaSharesDisplay.GetComponent<Text>().text = ShareManager.PlayerShares[3, 7].ToString();
        Player3RegalSharesDisplay.GetComponent<Text>().text = ShareManager.PlayerShares[3, 11].ToString();


        
        LuxorShareBalanceDisplay.GetComponent<Text>().text = HotelData.HotelShareCounter[1].ToString();
        LuxorShareValueDisplay.GetComponent<Text>().text = HotelData.ChainData[1, HotelData.ChainSize[1]].ToString();
        LuxorChainSizeDisplay.GetComponent<Text>().text = HotelData.ChainSize[1].ToString();
              
        GlobalShareBalanceDisplay.GetComponent<Text>().text = HotelData.HotelShareCounter[5].ToString();
        GlobalShareValueDisplay.GetComponent<Text>().text = HotelData.ChainData[5, HotelData.ChainSize[5]].ToString();
        GlobalChainSizeDisplay.GetComponent<Text>().text = HotelData.ChainSize[5].ToString();

        ArcadiaShareBalanceDisplay.GetComponent<Text>().text = HotelData.HotelShareCounter[7].ToString();
        ArcadiaShareValueDisplay.GetComponent<Text>().text = HotelData.ChainData[7, HotelData.ChainSize[7]].ToString();
        ArcadiaChainSizeDisplay.GetComponent<Text>().text = HotelData.ChainSize[7].ToString();
       
        RegalShareBalanceDisplay.GetComponent<Text>().text = HotelData.HotelShareCounter[11].ToString();
        RegalShareValueDisplay.GetComponent<Text>().text = HotelData.ChainData[11, HotelData.ChainSize[11]].ToString();
        RegalChainSizeDisplay.GetComponent<Text>().text = HotelData.ChainSize[11].ToString();

    }
        public void PlayerUpdatePanel()
    {                
        Player1CashDisplay.GetComponent<Text>().text = ShareManager.PlayerCash[1].ToString("###,###");
        Player1LuxorSharesDisplay.GetComponent<Text>().text = ShareManager.PlayerShares[1, 1].ToString();
        Player1GlobalSharesDisplay.GetComponent<Text>().text = ShareManager.PlayerShares[1, 5].ToString();
        Player1ArcadiaSharesDisplay.GetComponent<Text>().text = ShareManager.PlayerShares[1, 7].ToString();
        Player1RegalSharesDisplay.GetComponent<Text>().text = ShareManager.PlayerShares[1, 11].ToString();
        
        Player2CashDisplay.GetComponent<Text>().text = ShareManager.PlayerCash[2].ToString("###,###");
        Player2LuxorSharesDisplay.GetComponent<Text>().text = ShareManager.PlayerShares[2, 1].ToString();
        Player2GlobalSharesDisplay.GetComponent<Text>().text = ShareManager.PlayerShares[2, 5].ToString();
        Player2ArcadiaSharesDisplay.GetComponent<Text>().text = ShareManager.PlayerShares[2, 7].ToString();
        Player2RegalSharesDisplay.GetComponent<Text>().text = ShareManager.PlayerShares[2, 11].ToString();

        Player3CashDisplay.GetComponent<Text>().text = ShareManager.PlayerCash[3].ToString("###,###");
        Player3LuxorSharesDisplay.GetComponent<Text>().text = ShareManager.PlayerShares[3, 1].ToString();
        Player3GlobalSharesDisplay.GetComponent<Text>().text = ShareManager.PlayerShares[3, 5].ToString();
        Player3ArcadiaSharesDisplay.GetComponent<Text>().text = ShareManager.PlayerShares[3, 7].ToString();
        Player3RegalSharesDisplay.GetComponent<Text>().text = ShareManager.PlayerShares[3, 11].ToString();

    }
}


