using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Endgame : MonoBehaviour
{
    public void CalculatePlayerValue()
    {
        int i=1; int a =1;

        for(a=1;a<7;a++) 
        {  
            ShareManager.PlayerValue[a]=0;
            for(i=1;i<15;i++)
            {
                ShareManager.PlayerValue[a] = ShareManager.PlayerValue[a] + ShareManager.PlayerShares[a,i] * HotelData.ChainData[i,HotelData.ChainSize[i]];
                
            }
            ShareManager.PlayerValue[a] = ShareManager.PlayerValue[a] + ShareManager.PlayerCash[a];
        }

        //Debug.Log("Player One value is: "+ShareManager.PlayerValue[1]);
    }


}
