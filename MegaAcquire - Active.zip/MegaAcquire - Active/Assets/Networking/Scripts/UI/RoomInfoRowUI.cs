using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class RoomInfoRowUI : MonoBehaviour
{
    public System.Action<string> EvtClickJoin;
    [field: SerializeField] public string Id { get; set; }

    [SerializeField] private Text textRoomName;
    [SerializeField] private Text textPlayerCount;

        
    public void OnClickJoin()
    {
        EvtClickJoin?.Invoke(Id);
    }

    public void SetRoomName(string roomName)
    {
        textRoomName.text = roomName;
    }

    public void SetPlayerCount(int current,int max)
    {
        textPlayerCount.text = $"{current}/{max}";
    }
}
