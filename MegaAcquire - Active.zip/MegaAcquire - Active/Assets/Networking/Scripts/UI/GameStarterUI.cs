using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameStarterUI : MonoBehaviour
{
    public enum Mode
    {
        Pregame,
        Lobby
    }
    public interface IRoomInfo
    {
        string Id { get; }
        string Name { get; }
        int CurPlayer { get; }
        int MaxPlayer { get; }
    }
    [field: SerializeField] public string PlayerNickname { get; set; }

    [SerializeField] private Canvas pregameCanvas;
    [SerializeField] private Canvas lobbyCanvas;

    [SerializeField] private Transform roomListRoot;
    [SerializeField] private RoomInfoRowUI rowUIPrefab;

    [field: SerializeField] public string CreateRoomName { get; set; }
    
    private List<RoomInfoRowUI> rowUIList = new List<RoomInfoRowUI>();
    private Queue<RoomInfoRowUI> rowUIPoolQueue = new Queue<RoomInfoRowUI>();

    public System.Action<string> OnJoinLobbyClick;
    public System.Action<string> OnJoinRoomClick;
    public System.Action<string> OnCreateRoomClick;

    public void JoinLobby()
    {
        if(string.IsNullOrEmpty(PlayerNickname))
        {
            Debug.Log("Should enter nickname");
            PlayerNickname = "Andrew";
            //return;
        }

        OnJoinLobbyClick?.Invoke(PlayerNickname);
    }

    public void Show(Mode mode)
    {
        pregameCanvas.enabled = mode == Mode.Pregame;
        lobbyCanvas.enabled = mode == Mode.Lobby;
    }

    private void ClearAll()
    {
        foreach(var r in rowUIList)
        {
            r.gameObject.SetActive(false);
            rowUIPoolQueue.Enqueue(r);
        }        
        rowUIList.Clear();
    }
    private RoomInfoRowUI GetInstance()
    {
        RoomInfoRowUI ui = null;
        if(!rowUIPoolQueue.TryDequeue(out ui))
        {
            ui = Instantiate(rowUIPrefab, roomListRoot);
        }
        rowUIList.Add(ui);
        ui.gameObject.SetActive(true);     
        return ui;
    }

    public void DisplayRoomList(IEnumerable<IRoomInfo> roomInfos)
    {
        ClearAll();
        foreach(var r in roomInfos)
        {
            var ui = GetInstance();
            ui.Id = r.Id;
            ui.SetPlayerCount(r.CurPlayer, r.MaxPlayer);
            ui.SetRoomName(r.Name);
            ui.EvtClickJoin = ClickJoin;
        }

    }

    private void ClickJoin(string id)
    {
        OnJoinRoomClick?.Invoke(id);
    }

    public void CreateRoom()
    {
        OnCreateRoomClick?.Invoke(CreateRoomName);
    }
}
