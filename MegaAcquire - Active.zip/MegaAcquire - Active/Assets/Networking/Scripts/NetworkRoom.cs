using Fusion;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public struct PlayerNetworkData : INetworkStruct
{
    public PlayerRef playerConnect;
    public NetworkString<_32> name;
    public NetworkBool isReady;
}

public class NetworkRoom : NetworkBehaviour
{
    [Networked] public NetworkBool IsGameStarted { get; set; }

    [field: SerializeField] public int PlayerToStartGame { get; set; }       
    [Networked, Capacity(8)] public NetworkDictionary<PlayerRef, PlayerNetworkData> Players { get; }
    private int curPlayer = 0;

    [SerializeField] private NetworkPrefabRef gamePrefab;

    public bool IsStarted => Object != null && Object.IsValid && IsGameStarted;

    public override void Spawned()
    {
        if(Object.HasStateAuthority)
        {
            var events = Runner.GetBehaviour<NetworkEvents>();

            events.PlayerJoined.AddListener(OnPlayerJoined);
            events.PlayerLeft.AddListener(OnPlayerLeft);
        }        
    }

    private void OnPlayerJoined(NetworkRunner runner, PlayerRef player)
    {
        Debug.Log($"On Player joined!: {player}");
        if(IsGameStarted)
        {
            //LATER, WE CAN IMPLEMENT SOME METHOD TO LET OTHER PLAYER RECONNECTS
            runner.Disconnect(player);
            return;
        }

        if(curPlayer >= PlayerToStartGame)
        {
            //Disconnect this player
            runner.Disconnect(player);
            return;
        }

        //retrieve player name
        byte[] arr = runner.GetPlayerConnectionToken(player);

        string pName = string.Empty;

        if(arr != null)
        {
            pName = System.Text.Encoding.UTF8.GetString(arr);
        }
        else
        {
            pName = $"Player #{player.PlayerId}";
        }

        curPlayer++;
        Players.Set(player, new PlayerNetworkData
        {
            isReady = false,
            name = pName,
            playerConnect = player
        });
    }
    private void OnPlayerLeft(NetworkRunner runner, PlayerRef player)
    {
        if (IsGameStarted)
            return;

        if (Players.Remove(player))
        {
            curPlayer--;
        }
    }

    public void SetReady(bool isReady)
    {
        RpcSetReady(isReady);
    }

    [Rpc(RpcSources.All, RpcTargets.StateAuthority, HostMode = RpcHostMode.SourceIsHostPlayer)]
    
    // notify room owner that all players are ready to play
    private void RpcSetReady(bool isReady, RpcInfo info = default)
    {
        if(Players.TryGet(info.Source, out var player))
        {
            player.isReady = isReady;
            Players.Set(info.Source, player);
            Debug.Log($"Player: {player.name} is ready? {isReady}");
        }
    }

    public bool IsAllPlayerReady()
    {        
        foreach(var kv in Players)
        {
            if (kv.Key != PlayerRef.None && !kv.Value.isReady)
                return false;
        }
        return curPlayer == PlayerToStartGame;  
    }

    public bool IsRoomOwner() => HasStateAuthority;

    public void StartGame()
    {
        if(!Object.HasStateAuthority)
        {
            Debug.Log("You are not the room owner! Ignore this command");
            return;
        }

        if(IsGameStarted)
        {
            Debug.LogError("Game already started!");
            return;
        }

        IsGameStarted = true;
        //setting room info, then switch the scene
        //we can roll the player category here

        //instantiate the game
        Runner.Spawn(gamePrefab, onBeforeSpawned: (runner, no) =>
        {
            var acquireGame = no.GetBehaviour<NetworkBaseAcquireGame>();
            acquireGame.Initialize(this);
        });
    }

    private bool readyLocalToggle = false;

    [ContextMenu("Set Ready")]
    private void SetReady()
    {
        readyLocalToggle = !readyLocalToggle;
        //RpcSetReady(readyLocalToggle);
        StartCoroutine(CallReadyEditor(readyLocalToggle));
    }

    IEnumerator CallReadyEditor(bool isReady)
    {
        yield return null;
        RpcSetReady(isReady);
    }

    [ContextMenu("Check if all player ready")]
    private void CheckIfAllPlayerReady()
    {
        Debug.Log($"All player is ready: {IsAllPlayerReady()}");
    }

    [ContextMenu("Start game!")]
    private void CmdStartGame()
    {
        Debug.Log("Start Game!");
        //StartGame();
        StartCoroutine(CallStartGameEditor());
    }

    private IEnumerator CallStartGameEditor()
    {
        yield return null;
        StartGame();
    }

    public void GetPlayers(Dictionary<string, bool> players)
    {
        if (Object == null || !Object.IsValid)
            return;

        foreach(var kv in this.Players)
        {
            players.Add(kv.Value.name.ToString(), kv.Value.isReady);
        }
    }
}
