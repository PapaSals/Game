using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class StartingHotel : MonoBehaviour
{   
    [Header("Panel Information")]
    public GameObject StartHotelChainPanel;
   
    public int[] ChainID;
    public int GamePlayer=1;

    private TestAcquireGridVisual chain; 
    
    
    
    public void Awake()
    {
        chain = FindObjectOfType<TestAcquireGridVisual>();
        ChainID = new int[20];
        ChainID[0]=999;
        ChainID[1]=10;
        ChainID[5]=50;
        ChainID[7]=70;
        ChainID[11]=110;
    }

    public void ClosePanel()
    {
        Debug.Log("Closing Panel");
        StartHotelChainPanel.SetActive(false);
        //FindObjectOfType<ShareManager>().SharePurchasePanel.SetActive(true);
    }
    public void AddtoChain()
    {
        if(HotelData.HotelNum == 0 )
        {
        }
        else
        {
            Debug.Log("AddtoChain");
        }

        if(HotelData.HotelNum == 0){chain.ChainMaterial = chain.TileMaterial;}
        if(HotelData.HotelNum == 1){chain.ChainMaterial = chain.LuxorMaterial;}
        if(HotelData.HotelNum == 5){chain.ChainMaterial = chain.GlobalMaterial;}
        if(HotelData.HotelNum == 7){chain.ChainMaterial = chain.ArcadiaMaterial;}
        if(HotelData.HotelNum == 11){chain.ChainMaterial = chain.RegalMaterial;}
        
        var tile = chain.tiles[chain.p0Id].GetChild(0);
        tile.gameObject.SetActive(true);
        tile.gameObject.GetComponent<Renderer>().material = chain.ChainMaterial;
        chain.tiles[chain.p0Id].GetChild(1).gameObject.SetActive(false);
        chain.TileChain[chain.p0Id] = 999;
        
       
        StartChainRoutine();
        
        //FindObjectOfType<ShareManager>().SharePurchasePanel.SetActive(true);
    }
    public void StartChain ()
    {
       Debug.Log("SH 65    ------------------ StartChain() ------------------------ Hotel Count is : " + HotelData.HotelCount);
       if(HotelData.HotelCount <= HotelData.MaxHotel)
       {
            HotelData.HotelCount++;
            Debug.Log("-----------------  HotelCount is now: "+HotelData.HotelCount);
            StartChainRoutine();
       }
       else
       {
            StartHotelChainPanel.SetActive(false);
            Debug.Log("  ---------------  No more hotels available  ------------------");
            var tile = chain.tiles[chain.p0Id].GetChild(0);
            tile.gameObject.SetActive(true);
            tile.gameObject.GetComponent<Renderer>().material = chain.TileMaterial;
            chain.tiles[chain.p0Id].GetChild(1).gameObject.SetActive(false);
            chain.TileChain[chain.p0Id] = 999;
            FindObjectOfType<TestAcquireGridVisual>().SharePurchasePanel.SetActive(true);
            
        }
    }

    public void StartChainRoutine ()
    {
        Debug.Log("StartChainRoutine");
        if(HotelData.HotelNum == 0){chain.ChainMaterial = chain.TileMaterial;}
        if(HotelData.HotelNum == 1){chain.ChainMaterial = chain.LuxorMaterial;}
        if(HotelData.HotelNum == 5){chain.ChainMaterial = chain.GlobalMaterial;}
        if(HotelData.HotelNum == 7){chain.ChainMaterial = chain.ArcadiaMaterial;}
        if(HotelData.HotelNum == 11){chain.ChainMaterial = chain.RegalMaterial;}
        Debug.Log("Chain is "+ HotelData.HotelNum);

        if(chain.p0 == 999)
        {
        var p0 = chain.tiles[chain.p0Id].GetChild(0);
        p0.gameObject.SetActive(true);
        p0.gameObject.GetComponent<Renderer>().material = chain.ChainMaterial;
        chain.tiles[chain.p0Id].GetChild(1).gameObject.SetActive(false);
        chain.TileChain[chain.p0Id] = ChainID[HotelData.HotelNum];
        HotelData.ChainSize[HotelData.HotelNum] ++;
       
        
        }
        if(chain.p12 == 999)
        {
        var p12 = chain.tiles[chain.p12Id].GetChild(0);
        p12.gameObject.SetActive(true);
        p12.gameObject.GetComponent<Renderer>().material = chain.ChainMaterial;
        chain.tiles[chain.p12Id].GetChild(1).gameObject.SetActive(false);
        chain.TileChain[chain.p12Id] = ChainID[HotelData.HotelNum];
        HotelData.ChainSize[HotelData.HotelNum] ++;
       
        

        }
        if(chain.p6 == 999)
        {
        var p6 = chain.tiles[chain.p6Id].GetChild(0);
        p6.gameObject.SetActive(true);
        p6.gameObject.GetComponent<Renderer>().material = chain.ChainMaterial;
        chain.tiles[chain.p6Id].GetChild(1).gameObject.SetActive(false);
        chain.TileChain[chain.p6Id] = ChainID[HotelData.HotelNum];
        HotelData.ChainSize[HotelData.HotelNum] ++;
      
      
        }
        if(chain.p8 == 999)
        {
        var p8 = chain.tiles[chain.p8Id].GetChild(0);
        p8.gameObject.SetActive(true);
        p8.gameObject.GetComponent<Renderer>().material = chain.ChainMaterial;
        chain.tiles[chain.p8Id].GetChild(1).gameObject.SetActive(false);
        chain.TileChain[chain.p8Id] = ChainID[HotelData.HotelNum];
        HotelData.ChainSize[HotelData.HotelNum] ++;
      
   
        }
        if(chain.p10 == 999)
        {
        var p10 = chain.tiles[chain.p10Id].GetChild(0);
        p10.gameObject.SetActive(true);
        p10.gameObject.GetComponent<Renderer>().material = chain.ChainMaterial;
        chain.tiles[chain.p10Id].GetChild(1).gameObject.SetActive(false);
        chain.TileChain[chain.p10Id] = ChainID[HotelData.HotelNum];
        HotelData.ChainSize[HotelData.HotelNum] ++;
      
        }
        if(chain.p2 == 999)
        {
        var p2 = chain.tiles[chain.p2Id].GetChild(0);
        p2.gameObject.SetActive(true);
        p2.gameObject.GetComponent<Renderer>().material = chain.ChainMaterial;
        chain.tiles[chain.p2Id].GetChild(1).gameObject.SetActive(false);
        chain.TileChain[chain.p2Id] = ChainID[HotelData.HotelNum];
        HotelData.ChainSize[HotelData.HotelNum] ++;
       
        }
        if(chain.p4 == 999)
        {
        var p4 = chain.tiles[chain.p4Id].GetChild(0);
        p4.gameObject.SetActive(true);
        p4.gameObject.GetComponent<Renderer>().material = chain.ChainMaterial;
        chain.tiles[chain.p4Id].GetChild(1).gameObject.SetActive(false);
        chain.TileChain[chain.p4Id] = ChainID[HotelData.HotelNum];
        HotelData.ChainSize[HotelData.HotelNum] ++;
      
        }
        
        Debug.Log("SH 170  " + HotelData.HotelName[HotelData.HotelNum] + " has " + HotelData.ChainSize[HotelData.HotelNum]+ " Tiles");
        FindObjectOfType<Scoreboard>().Updateleaderboard();
        
        //Debug.Log("SH142                                        "+chain.TileChain[chain.p12Id]);
        //Debug.Log("SH143                                  "+chain.TileChain[chain.p10Id]+"          "+chain.TileChain[chain.p2Id]);
        //Debug.Log("SH144                                        "+chain.TileChain[chain.p0Id]);
        //Debug.Log("SH145                                  "+chain.TileChain[chain.p8Id]+"          "+chain.TileChain[chain.p4Id]);
        //Debug.Log("SH146                                        "+chain.TileChain[chain.p6Id]);
        
        //Debug.Log("SH142                                        "+chain.p12Id);
        //Debug.Log("SH143                                  "+chain.p10Id+"         "+chain.p2Id);
        //Debug.Log("SH144                                        "+chain.p0Id);
        //Debug.Log("SH145                                  "+chain.p8Id+"          "+chain.p4Id);
        //Debug.Log("SH146                                        "+chain.p6Id);      



    }
        public void FoundersShare()
    {
        //FindObjectOfType<ShareManager>().PlaceTilePanel.SetActive(false); 
     
        Debug.Log("HotelNum is: "+HotelData.HotelNum);
        Debug.Log("HotelData.HotelFounder is: "+HotelData.HotelFounder[HotelData.HotelNum]);
        
        if (HotelData.HotelFounder[1] == 1 && HotelData.HotelNum == 1)
        {
            //HotelData.ChainSize[1] = LuxorChain.GetComponent<Chain>().ChainSize;
            Debug.Log("Luxor Chain Size is :"+HotelData.ChainSize[1]);
            FoundersShareRoutine();
        }
        else if(HotelData.HotelFounder[5] == 1 && HotelData.HotelNum == 5)
        {
            //HotelData.ChainSize[5] = GlobalChain.GetComponent<Chain>().ChainSize;
            Debug.Log("Global Chain Size is :"+HotelData.ChainSize[5]); 
            FoundersShareRoutine();
        }         
        else if(HotelData.HotelFounder[7] == 1 && HotelData.HotelNum == 7)
        {
            //HotelData.ChainSize[7] = ArcadiaChain.GetComponent<Chain>().ChainSize;
            Debug.Log("Arcadia Chain Size is :"+HotelData.ChainSize[7]);
            FoundersShareRoutine();
        }
        else if (HotelData.HotelFounder[11] == 1 && HotelData.HotelNum == 11)
        {
            //HotelData.ChainSize[11] = RegalChain.GetComponent<Chain>().ChainSize;
            Debug.Log("Regal Chain Size is :"+HotelData.ChainSize[11]);
            FoundersShareRoutine();  
        }
        else
        {
            Debug.Log("No Founders Share is Available");  
        }
        Debug.Log("FoundersShare()  Hotel # is "+ HotelData.HotelNum + "  Hotel Size is "+HotelData.ChainSize[HotelData.HotelNum]);
     
        FindObjectOfType<Scoreboard>().Updateleaderboard();
    }
    public void FoundersShareRoutine()
    {
        GamePlayer = 1;
        Debug.Log("GamePlayer is: "+ GamePlayer); 
        ShareManager.PlayerShares[GamePlayer, HotelData.HotelNum] = ShareManager.PlayerShares[GamePlayer, HotelData.HotelNum] + 1; // Adding Founder's Share
        HotelData.HotelShareCounter[HotelData.HotelNum] = HotelData.HotelShareCounter[HotelData.HotelNum] - 1 ;   // reduce sharebalance by 1
        //Debug.Log("FoundersShareRoutine - FoundersHotel is # "+HotelData.HotelNum); 
        HotelData.HotelFounder[HotelData.HotelNum] = 0;
       

    }
    
}
