using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundEffects : MonoBehaviour
{
    public AudioSource Ding; 
    public AudioSource Luxor;
    public AudioSource Global;
    public AudioSource Arcadia;
    public AudioSource Regal;
  
    //duplicate for more sounds

    public void PlayDing()      { Ding.Play();    }
    public void PlayGlobal()    { Global.Play();  }
    public void PlayRegal()     { Regal.Play();   }
    public void PlayArcadia()   { Arcadia.Play(); }
    public void PlayLuxor()     { Luxor.Play();   }

}
